#include "work_form.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QKeyEvent>
#include <QSqlQuery>
#include <QSqlError>

WorkForm::WorkForm(int id, QWidget* parent)
    : QWidget(parent), m_id(id) {
    setupUi();
    if (m_id > 0) {
        loadData();
    }
}

void WorkForm::setupUi() {
    setWindowTitle(m_id > 0 ? "Редактирование вида работ" : "Новый вид работ");
    setAttribute(Qt::WA_DeleteOnClose);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    QFormLayout* formLayout = new QFormLayout();
    
    m_nameEdit = new QLineEdit();
    connect(m_nameEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Наименование*:", m_nameEdit);
    
    m_unitEdit = new QLineEdit();
    connect(m_unitEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Единица измерения:", m_unitEdit);
    
    m_priceSpinBox = new QDoubleSpinBox();
    m_priceSpinBox->setMaximum(999999999.99);
    m_priceSpinBox->setDecimals(2);
    connect(m_priceSpinBox, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            [this]() { m_isModified = true; });
    formLayout->addRow("Цена:", m_priceSpinBox);
    
    m_laborRateSpinBox = new QDoubleSpinBox();
    m_laborRateSpinBox->setMaximum(999999.99);
    m_laborRateSpinBox->setDecimals(2);
    connect(m_laborRateSpinBox, QOverload<double>::of(&QDoubleSpinBox::valueChanged),
            [this]() { m_isModified = true; });
    formLayout->addRow("Норма трудозатрат:", m_laborRateSpinBox);
    
    mainLayout->addLayout(formLayout);
    
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    
    QPushButton* saveButton = new QPushButton("Сохранить (Ctrl+S)");
    connect(saveButton, &QPushButton::clicked, this, &WorkForm::onSave);
    buttonLayout->addWidget(saveButton);
    
    QPushButton* saveCloseButton = new QPushButton("Сохранить и закрыть (Ctrl+Shift+S)");
    connect(saveCloseButton, &QPushButton::clicked, this, &WorkForm::onSaveAndClose);
    buttonLayout->addWidget(saveCloseButton);
    
    QPushButton* closeButton = new QPushButton("Закрыть (Esc)");
    connect(closeButton, &QPushButton::clicked, this, &WorkForm::onClose);
    buttonLayout->addWidget(closeButton);
    
    mainLayout->addLayout(buttonLayout);
    m_nameEdit->setFocus();
}

void WorkForm::loadData() {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT name, unit, price, labor_rate FROM works WHERE id = ?");
    query.addBindValue(m_id);
    
    if (query.exec() && query.next()) {
        m_nameEdit->setText(query.value(0).toString());
        m_unitEdit->setText(query.value(1).toString());
        m_priceSpinBox->setValue(query.value(2).toDouble());
        m_laborRateSpinBox->setValue(query.value(3).toDouble());
        m_isModified = false;
    }
}

bool WorkForm::saveData() {
    if (m_nameEdit->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Наименование обязательно для заполнения");
        m_nameEdit->setFocus();
        return false;
    }
    
    QSqlQuery query(DatabaseManager::instance().database());
    
    if (m_id > 0) {
        query.prepare("UPDATE works SET name = ?, unit = ?, price = ?, labor_rate = ? WHERE id = ?");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_unitEdit->text());
        query.addBindValue(m_priceSpinBox->value());
        query.addBindValue(m_laborRateSpinBox->value());
        query.addBindValue(m_id);
    } else {
        query.prepare("INSERT INTO works (name, unit, price, labor_rate) VALUES (?, ?, ?, ?)");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_unitEdit->text());
        query.addBindValue(m_priceSpinBox->value());
        query.addBindValue(m_laborRateSpinBox->value());
    }
    
    if (query.exec()) {
        if (m_id <= 0) {
            m_id = query.lastInsertId().toInt();
        }
        m_isModified = false;
        setWindowTitle("Редактирование вида работ");
        return true;
    } else {
        QMessageBox::critical(this, "Ошибка", "Не удалось сохранить: " + query.lastError().text());
        return false;
    }
}

void WorkForm::onSave() {
    saveData();
}

void WorkForm::onSaveAndClose() {
    if (saveData()) {
        close();
    }
}

void WorkForm::onClose() {
    close();
}

void WorkForm::closeEvent(QCloseEvent* event) {
    if (m_isModified) {
        QMessageBox::StandardButton reply = QMessageBox::question(
            this, "Несохраненные изменения",
            "Документ был изменен. Сохранить изменения?",
            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        
        if (reply == QMessageBox::Yes) {
            if (saveData()) {
                event->accept();
            } else {
                event->ignore();
            }
        } else if (reply == QMessageBox::No) {
            event->accept();
        } else {
            event->ignore();
        }
    } else {
        event->accept();
    }
}

void WorkForm::keyPressEvent(QKeyEvent* event) {
    if (event->matches(QKeySequence::Save)) {
        onSave();
    } else if (event->key() == Qt::Key_S && 
               event->modifiers() == (Qt::ControlModifier | Qt::ShiftModifier)) {
        onSaveAndClose();
    } else if (event->key() == Qt::Key_Escape) {
        onClose();
    } else {
        QWidget::keyPressEvent(event);
    }
}
