#include "estimate_service.h"
#include "data/repositories/estimate_repository.h"

Estimate* EstimateService::create() {
    return new Estimate();
}

Estimate* EstimateService::load(int id) {
    EstimateRepository repo;
    return repo.findById(id);
}

bool EstimateService::save(Estimate* estimate) {
    EstimateRepository repo;
    return repo.save(estimate);
}
