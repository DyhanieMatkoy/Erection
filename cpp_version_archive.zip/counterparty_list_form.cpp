#include "counterparty_list_form.h"
#include "counterparty_form.h"

CounterpartyListForm::CounterpartyListForm(QWidget* parent)
    : BaseListForm(parent) {
}

void CounterpartyListForm::configureColumns() {
    // Настройка отображения колонок
}

QWidget* CounterpartyListForm::createEditForm(int id) {
    return new CounterpartyForm(id);
}
