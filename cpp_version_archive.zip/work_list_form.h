#pragma once
#include "base_list_form.h"

class WorkListForm : public BaseListForm {
    Q_OBJECT
    
public:
    explicit WorkListForm(QWidget* parent = nullptr);
    
protected:
    QString tableName() const override { return "works"; }
    QString formTitle() const override { return "Виды работ"; }
    void configureColumns() override;
    QWidget* createEditForm(int id) override;
};
