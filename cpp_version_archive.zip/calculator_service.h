#pragma once

class CalculatorService {
public:
    static double calculateSum(double quantity, double price);
    static double calculateLabor(double quantity, double laborRate);
    static double calculateDeviation(double planned, double actual);
};
