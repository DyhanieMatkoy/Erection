#include "counterparty_form.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QKeyEvent>
#include <QSqlQuery>
#include <QSqlError>

CounterpartyForm::CounterpartyForm(int id, QWidget* parent)
    : QWidget(parent), m_id(id) {
    setupUi();
    if (m_id > 0) {
        loadData();
    }
}

void CounterpartyForm::setupUi() {
    setWindowTitle(m_id > 0 ? "Редактирование контрагента" : "Новый контрагент");
    setAttribute(Qt::WA_DeleteOnClose);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    
    // Форма
    QFormLayout* formLayout = new QFormLayout();
    
    m_nameEdit = new QLineEdit();
    connect(m_nameEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Наименование*:", m_nameEdit);
    
    m_innEdit = new QLineEdit();
    connect(m_innEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("ИНН:", m_innEdit);
    
    m_contactPersonEdit = new QLineEdit();
    connect(m_contactPersonEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Контактное лицо:", m_contactPersonEdit);
    
    m_phoneEdit = new QLineEdit();
    connect(m_phoneEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Телефон:", m_phoneEdit);
    
    mainLayout->addLayout(formLayout);
    
    // Кнопки
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    
    m_saveButton = new QPushButton("Сохранить (Ctrl+S)");
    connect(m_saveButton, &QPushButton::clicked, this, &CounterpartyForm::onSave);
    buttonLayout->addWidget(m_saveButton);
    
    m_saveCloseButton = new QPushButton("Сохранить и закрыть (Ctrl+Shift+S)");
    connect(m_saveCloseButton, &QPushButton::clicked, this, &CounterpartyForm::onSaveAndClose);
    buttonLayout->addWidget(m_saveCloseButton);
    
    m_closeButton = new QPushButton("Закрыть (Esc)");
    connect(m_closeButton, &QPushButton::clicked, this, &CounterpartyForm::onClose);
    buttonLayout->addWidget(m_closeButton);
    
    mainLayout->addLayout(buttonLayout);
    
    m_nameEdit->setFocus();
}

void CounterpartyForm::loadData() {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT name, inn, contact_person, phone FROM counterparties WHERE id = ?");
    query.addBindValue(m_id);
    
    if (query.exec() && query.next()) {
        m_nameEdit->setText(query.value(0).toString());
        m_innEdit->setText(query.value(1).toString());
        m_contactPersonEdit->setText(query.value(2).toString());
        m_phoneEdit->setText(query.value(3).toString());
        m_isModified = false;
    }
}

bool CounterpartyForm::saveData() {
    if (m_nameEdit->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Наименование обязательно для заполнения");
        m_nameEdit->setFocus();
        return false;
    }
    
    QSqlQuery query(DatabaseManager::instance().database());
    
    if (m_id > 0) {
        query.prepare("UPDATE counterparties SET name = ?, inn = ?, contact_person = ?, phone = ? WHERE id = ?");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_innEdit->text());
        query.addBindValue(m_contactPersonEdit->text());
        query.addBindValue(m_phoneEdit->text());
        query.addBindValue(m_id);
    } else {
        query.prepare("INSERT INTO counterparties (name, inn, contact_person, phone) VALUES (?, ?, ?, ?)");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_innEdit->text());
        query.addBindValue(m_contactPersonEdit->text());
        query.addBindValue(m_phoneEdit->text());
    }
    
    if (query.exec()) {
        if (m_id <= 0) {
            m_id = query.lastInsertId().toInt();
        }
        m_isModified = false;
        setWindowTitle("Редактирование контрагента");
        return true;
    } else {
        QMessageBox::critical(this, "Ошибка", "Не удалось сохранить: " + query.lastError().text());
        return false;
    }
}

void CounterpartyForm::onSave() {
    saveData();
}

void CounterpartyForm::onSaveAndClose() {
    if (saveData()) {
        close();
    }
}

void CounterpartyForm::onClose() {
    close();
}

void CounterpartyForm::closeEvent(QCloseEvent* event) {
    if (m_isModified) {
        QMessageBox::StandardButton reply = QMessageBox::question(
            this, "Несохраненные изменения",
            "Документ был изменен. Сохранить изменения?",
            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        
        if (reply == QMessageBox::Yes) {
            if (saveData()) {
                event->accept();
            } else {
                event->ignore();
            }
        } else if (reply == QMessageBox::No) {
            event->accept();
        } else {
            event->ignore();
        }
    } else {
        event->accept();
    }
}

void CounterpartyForm::keyPressEvent(QKeyEvent* event) {
    if (event->matches(QKeySequence::Save)) {
        onSave();
    } else if (event->key() == Qt::Key_S && 
               event->modifiers() == (Qt::ControlModifier | Qt::ShiftModifier)) {
        onSaveAndClose();
    } else if (event->key() == Qt::Key_Escape) {
        onClose();
    } else {
        QWidget::keyPressEvent(event);
    }
}
