#pragma once
#include "data/models/user.h"

class UserRepository {
public:
    User* findByUsername(const QString& username);
};
