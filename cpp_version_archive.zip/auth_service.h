#pragma once
#include "data/models/user.h"
#include <QString>

class AuthService {
public:
    static AuthService& instance();
    
    User* login(const QString& username, const QString& password);
    void logout();
    User* currentUser() const;
    bool hasPermission(const QString& action) const;
    
private:
    AuthService() : m_currentUser(nullptr) {}
    ~AuthService() { logout(); }
    AuthService(const AuthService&) = delete;
    AuthService& operator=(const AuthService&) = delete;
    
    QString hashPassword(const QString& password);
    User* m_currentUser;
};
