#include "document_view_model.h"

DocumentViewModel::DocumentViewModel(QObject* parent) : QObject(parent) {
}
