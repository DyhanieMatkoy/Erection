#include "estimate_repository.h"
#include "data/database_manager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

Estimate* EstimateRepository::findById(int id) {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT * FROM estimates WHERE id = ?");
    query.addBindValue(id);
    
    if (!query.exec() || !query.next()) {
        return nullptr;
    }
    
    auto estimate = new Estimate();
    estimate->setId(query.value("id").toInt());
    estimate->setNumber(query.value("number").toString());
    estimate->setDate(query.value("date").toDate());
    estimate->setCustomerId(query.value("customer_id").toInt());
    estimate->setObjectId(query.value("object_id").toInt());
    estimate->setContractorId(query.value("contractor_id").toInt());
    estimate->setResponsibleId(query.value("responsible_id").toInt());
    estimate->setTotalSum(query.value("total_sum").toDouble());
    estimate->setTotalLabor(query.value("total_labor").toDouble());
    
    loadLines(estimate);
    return estimate;
}

bool EstimateRepository::save(Estimate* estimate) {
    QSqlDatabase db = DatabaseManager::instance().database();
    db.transaction();
    
    QSqlQuery query(db);
    if (estimate->id() == 0) {
        query.prepare("INSERT INTO estimates (number, date, customer_id, object_id, "
                     "contractor_id, responsible_id, total_sum, total_labor) "
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    } else {
        query.prepare("UPDATE estimates SET number=?, date=?, customer_id=?, object_id=?, "
                     "contractor_id=?, responsible_id=?, total_sum=?, total_labor=?, "
                     "modified_at=CURRENT_TIMESTAMP WHERE id=?");
    }
    
    query.addBindValue(estimate->number());
    query.addBindValue(estimate->date());
    query.addBindValue(estimate->customerId());
    query.addBindValue(estimate->objectId());
    query.addBindValue(estimate->contractorId());
    query.addBindValue(estimate->responsibleId());
    query.addBindValue(estimate->totalSum());
    query.addBindValue(estimate->totalLabor());
    
    if (estimate->id() != 0) {
        query.addBindValue(estimate->id());
    }
    
    if (!query.exec()) {
        db.rollback();
        qCritical() << "Failed to save estimate:" << query.lastError().text();
        return false;
    }
    
    if (estimate->id() == 0) {
        estimate->setId(query.lastInsertId().toInt());
    }
    
    if (!saveLines(estimate)) {
        db.rollback();
        return false;
    }
    
    db.commit();
    return true;
}

QList<Estimate*> EstimateRepository::findByResponsible(int personId) {
    QList<Estimate*> result;
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT * FROM estimates WHERE responsible_id = ? ORDER BY date DESC");
    query.addBindValue(personId);
    
    if (!query.exec()) {
        return result;
    }
    
    while (query.next()) {
        auto estimate = new Estimate();
        estimate->setId(query.value("id").toInt());
        estimate->setNumber(query.value("number").toString());
        estimate->setDate(query.value("date").toDate());
        result.append(estimate);
    }
    
    return result;
}

void EstimateRepository::loadLines(Estimate* estimate) {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT * FROM estimate_lines WHERE estimate_id = ? ORDER BY line_number");
    query.addBindValue(estimate->id());
    
    if (!query.exec()) {
        return;
    }
    
    while (query.next()) {
        auto line = new EstimateLine();
        line->setId(query.value("id").toInt());
        line->setEstimateId(estimate->id());
        line->setLineNumber(query.value("line_number").toInt());
        line->setWorkId(query.value("work_id").toInt());
        line->setQuantity(query.value("quantity").toDouble());
        line->setUnit(query.value("unit").toString());
        line->setPrice(query.value("price").toDouble());
        line->setLaborRate(query.value("labor_rate").toDouble());
        line->setSum(query.value("sum").toDouble());
        line->setPlannedLabor(query.value("planned_labor").toDouble());
        estimate->lines().append(line);
    }
}

bool EstimateRepository::saveLines(Estimate* estimate) {
    QSqlQuery deleteQuery(DatabaseManager::instance().database());
    deleteQuery.prepare("DELETE FROM estimate_lines WHERE estimate_id = ?");
    deleteQuery.addBindValue(estimate->id());
    
    if (!deleteQuery.exec()) {
        return false;
    }
    
    QSqlQuery insertQuery(DatabaseManager::instance().database());
    insertQuery.prepare("INSERT INTO estimate_lines (estimate_id, line_number, work_id, "
                       "quantity, unit, price, labor_rate, sum, planned_labor) "
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    for (int i = 0; i < estimate->lines().size(); ++i) {
        auto line = estimate->lines()[i];
        insertQuery.addBindValue(estimate->id());
        insertQuery.addBindValue(i + 1);
        insertQuery.addBindValue(line->workId());
        insertQuery.addBindValue(line->quantity());
        insertQuery.addBindValue(line->unit());
        insertQuery.addBindValue(line->price());
        insertQuery.addBindValue(line->laborRate());
        insertQuery.addBindValue(line->sum());
        insertQuery.addBindValue(line->plannedLabor());
        
        if (!insertQuery.exec()) {
            return false;
        }
    }
    
    return true;
}
