#include "base_table_part.h"
#include <QKeyEvent>

BaseTablePart::BaseTablePart(QWidget* parent) : QTableView(parent) {
}

void BaseTablePart::keyPressEvent(QKeyEvent* event) {
    if (event->key() == Qt::Key_Insert) {
        onInsertRow();
    } else if (event->key() == Qt::Key_Delete) {
        onDeleteRow();
    } else if (event->key() == Qt::Key_F4) {
        onF4Pressed();
    }
    QTableView::keyPressEvent(event);
}

void BaseTablePart::onInsertRow() {
}

void BaseTablePart::onDeleteRow() {
}

void BaseTablePart::onF4Pressed() {
}
