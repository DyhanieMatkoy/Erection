#pragma once

template<typename T>
class ReferenceRepository {
public:
    virtual ~ReferenceRepository() = default;
};
