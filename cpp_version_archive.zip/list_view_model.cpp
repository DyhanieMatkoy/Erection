#include "list_view_model.h"

ListViewModel::ListViewModel(QObject* parent) : QObject(parent) {
}
