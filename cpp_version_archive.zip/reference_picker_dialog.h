#pragma once
#include <QDialog>
#include <QTableView>
#include <QLineEdit>
#include <QPushButton>
#include <QSqlTableModel>

class ReferencePickerDialog : public QDialog {
    Q_OBJECT
    
public:
    explicit ReferencePickerDialog(const QString& tableName, const QString& displayColumn,
                                   QWidget* parent = nullptr);
    
    int selectedId() const { return m_selectedId; }
    QString selectedValue() const { return m_selectedValue; }
    
protected:
    void keyPressEvent(QKeyEvent* event) override;
    
private slots:
    void onSearchTextChanged(const QString& text);
    void onTableDoubleClicked(const QModelIndex& index);
    void onSelectClicked();
    void onCancelClicked();
    
private:
    void setupUi();
    void loadData();
    
    QString m_tableName;
    QString m_displayColumn;
    int m_selectedId = -1;
    QString m_selectedValue;
    
    QTableView* m_tableView;
    QLineEdit* m_searchEdit;
    QPushButton* m_selectButton;
    QPushButton* m_cancelButton;
    QSqlTableModel* m_model;
};
