#include "base_document_form.h"
#include <QKeyEvent>
#include <QMessageBox>

BaseDocumentForm::BaseDocumentForm(QWidget* parent) 
    : QWidget(parent), m_modified(false) {
}

void BaseDocumentForm::keyPressEvent(QKeyEvent* event) {
    if (event->matches(QKeySequence::Save)) {
        onSave();
    } else if (event->key() == Qt::Key_S && 
               event->modifiers() == (Qt::ControlModifier | Qt::ShiftModifier)) {
        onSaveAndClose();
    } else if (event->key() == Qt::Key_Escape) {
        onClose();
    } else if (event->matches(QKeySequence::Print)) {
        onPrint();
    }
    QWidget::keyPressEvent(event);
}

void BaseDocumentForm::onSave() {
}

void BaseDocumentForm::onSaveAndClose() {
    onSave();
    close();
}

void BaseDocumentForm::onClose() {
    if (hasUnsavedChanges()) {
        auto reply = QMessageBox::question(this, "Подтверждение",
            "Есть несохраненные изменения. Сохранить?",
            QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        
        if (reply == QMessageBox::Save) {
            onSave();
        } else if (reply == QMessageBox::Cancel) {
            return;
        }
    }
    close();
}

void BaseDocumentForm::onPrint() {
}

bool BaseDocumentForm::hasUnsavedChanges() const {
    return m_modified;
}
