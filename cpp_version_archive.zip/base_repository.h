#pragma once

template<typename T>
class BaseRepository {
public:
    virtual ~BaseRepository() = default;
    virtual T* findById(int id) = 0;
    virtual bool save(T* entity) = 0;
};
