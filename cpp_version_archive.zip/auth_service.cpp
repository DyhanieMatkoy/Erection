#include "auth_service.h"
#include "data/repositories/user_repository.h"
#include <QCryptographicHash>

AuthService& AuthService::instance() {
    static AuthService instance;
    return instance;
}

User* AuthService::login(const QString& username, const QString& password) {
    UserRepository repo;
    User* user = repo.findByUsername(username);
    
    if (!user) {
        return nullptr;
    }
    
    QString hash = hashPassword(password);
    if (user->passwordHash() != hash) {
        delete user;
        return nullptr;
    }
    
    m_currentUser = user;
    return user;
}

void AuthService::logout() {
    if (m_currentUser) {
        delete m_currentUser;
        m_currentUser = nullptr;
    }
}

User* AuthService::currentUser() const {
    return m_currentUser;
}

bool AuthService::hasPermission(const QString& action) const {
    if (!m_currentUser) return false;
    
    QString role = m_currentUser->role();
    if (role == "Администратор" || role == "Руководитель") {
        return true;
    }
    
    return false;
}

QString AuthService::hashPassword(const QString& password) {
    return QString(QCryptographicHash::hash(password.toUtf8(), 
                                            QCryptographicHash::Sha256).toHex());
}
