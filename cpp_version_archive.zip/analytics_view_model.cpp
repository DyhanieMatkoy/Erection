#include "analytics_view_model.h"

AnalyticsViewModel::AnalyticsViewModel(QObject* parent) : QObject(parent) {
}
