#pragma once
#include <QString>

class ValidationService {
public:
    static bool validateEstimate(class Estimate* estimate, QString& error);
};
