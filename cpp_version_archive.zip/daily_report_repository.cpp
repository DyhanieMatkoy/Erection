#include "daily_report_repository.h"
