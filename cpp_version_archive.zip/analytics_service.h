#pragma once
#include <QString>
#include <QDate>
#include <QList>
#include <QVariantMap>

struct AnalyticsData {
    int estimateId;
    QString estimateNumber;
    QString objectName;
    double plannedLabor;
    double actualLabor;
    double deviationPercent;
    double plannedCost;
    double actualCost;
    double costDeviation;
};

class AnalyticsService {
public:
    static AnalyticsService& instance();
    
    // Получить аналитику за период (время < 10 сек)
    QList<AnalyticsData> getAnalytics(const QDate& startDate, const QDate& endDate,
                                      int estimateId = -1, int objectId = -1, int responsibleId = -1);
    
    // Получить детализацию по смете
    QList<QVariantMap> getDetails(int estimateId);
    
    // Экспорт в различные форматы
    bool exportToPdf(const QList<AnalyticsData>& data, const QString& filePath);
    bool exportToExcel(const QList<AnalyticsData>& data, const QString& filePath);
    bool exportToCsv(const QList<AnalyticsData>& data, const QString& filePath);
    
private:
    AnalyticsService() = default;
    ~AnalyticsService() = default;
    AnalyticsService(const AnalyticsService&) = delete;
    AnalyticsService& operator=(const AnalyticsService&) = delete;
};
