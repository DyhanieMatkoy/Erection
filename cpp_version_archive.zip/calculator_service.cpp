#include "calculator_service.h"

double CalculatorService::calculateSum(double quantity, double price) {
    return quantity * price;
}

double CalculatorService::calculateLabor(double quantity, double laborRate) {
    return quantity * laborRate;
}

double CalculatorService::calculateDeviation(double planned, double actual) {
    if (planned == 0.0) return 0.0;
    return ((actual - planned) / planned) * 100.0;
}
