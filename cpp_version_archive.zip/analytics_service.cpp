#include "analytics_service.h"
#include "../data/database_manager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QPdfWriter>
#include <QPainter>

AnalyticsService& AnalyticsService::instance() {
    static AnalyticsService instance;
    return instance;
}

QList<AnalyticsData> AnalyticsService::getAnalytics(const QDate& startDate, const QDate& endDate,
                                                     int estimateId, int objectId, int responsibleId) {
    QList<AnalyticsData> result;
    
    QString sql = 
        "SELECT "
        "e.id, e.number, o.name as object_name, "
        "e.total_labor as planned_labor, "
        "COALESCE(SUM(drl.actual_labor), 0) as actual_labor, "
        "e.total_sum as planned_cost "
        "FROM estimates e "
        "LEFT JOIN objects o ON e.object_id = o.id "
        "LEFT JOIN daily_reports dr ON dr.estimate_id = e.id "
        "LEFT JOIN daily_report_lines drl ON drl.report_id = dr.id "
        "WHERE e.date BETWEEN ? AND ? ";
    
    if (estimateId > 0) {
        sql += "AND e.id = ? ";
    }
    if (objectId > 0) {
        sql += "AND e.object_id = ? ";
    }
    if (responsibleId > 0) {
        sql += "AND e.responsible_id = ? ";
    }
    
    sql += "GROUP BY e.id, e.number, o.name, e.total_labor, e.total_sum";
    
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare(sql);
    query.addBindValue(startDate);
    query.addBindValue(endDate);
    
    if (estimateId > 0) query.addBindValue(estimateId);
    if (objectId > 0) query.addBindValue(objectId);
    if (responsibleId > 0) query.addBindValue(responsibleId);
    
    if (!query.exec()) {
        qCritical() << "Failed to get analytics:" << query.lastError().text();
        return result;
    }
    
    while (query.next()) {
        AnalyticsData data;
        data.estimateId = query.value(0).toInt();
        data.estimateNumber = query.value(1).toString();
        data.objectName = query.value(2).toString();
        data.plannedLabor = query.value(3).toDouble();
        data.actualLabor = query.value(4).toDouble();
        data.plannedCost = query.value(5).toDouble();
        
        // Расчет отклонений
        if (data.plannedLabor > 0) {
            data.deviationPercent = ((data.actualLabor - data.plannedLabor) / data.plannedLabor) * 100.0;
        } else {
            data.deviationPercent = 0.0;
        }
        
        // Фактическая стоимость пропорциональна фактическим трудозатратам
        if (data.plannedLabor > 0) {
            data.actualCost = data.plannedCost * (data.actualLabor / data.plannedLabor);
        } else {
            data.actualCost = 0.0;
        }
        
        data.costDeviation = data.actualCost - data.plannedCost;
        
        result.append(data);
    }
    
    return result;
}

QList<QVariantMap> AnalyticsService::getDetails(int estimateId) {
    QList<QVariantMap> result;
    
    QString sql = 
        "SELECT "
        "w.name as work_name, "
        "el.quantity, el.unit, el.price, el.sum, el.planned_labor, "
        "COALESCE(SUM(drl.actual_labor), 0) as actual_labor "
        "FROM estimate_lines el "
        "LEFT JOIN works w ON el.work_id = w.id "
        "LEFT JOIN daily_report_lines drl ON drl.work_id = el.work_id "
        "LEFT JOIN daily_reports dr ON drl.report_id = dr.id AND dr.estimate_id = ? "
        "WHERE el.estimate_id = ? "
        "GROUP BY el.id, w.name, el.quantity, el.unit, el.price, el.sum, el.planned_labor";
    
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare(sql);
    query.addBindValue(estimateId);
    query.addBindValue(estimateId);
    
    if (!query.exec()) {
        qCritical() << "Failed to get details:" << query.lastError().text();
        return result;
    }
    
    while (query.next()) {
        QVariantMap row;
        row["work_name"] = query.value(0).toString();
        row["quantity"] = query.value(1).toDouble();
        row["unit"] = query.value(2).toString();
        row["price"] = query.value(3).toDouble();
        row["sum"] = query.value(4).toDouble();
        row["planned_labor"] = query.value(5).toDouble();
        row["actual_labor"] = query.value(6).toDouble();
        
        double plannedLabor = query.value(5).toDouble();
        double actualLabor = query.value(6).toDouble();
        if (plannedLabor > 0) {
            row["deviation_percent"] = ((actualLabor - plannedLabor) / plannedLabor) * 100.0;
        } else {
            row["deviation_percent"] = 0.0;
        }
        
        result.append(row);
    }
    
    return result;
}

bool AnalyticsService::exportToPdf(const QList<AnalyticsData>& data, const QString& filePath) {
    QPdfWriter writer(filePath);
    writer.setPageSize(QPageSize::A4);
    writer.setPageMargins(QMarginsF(15, 15, 15, 15));
    
    QPainter painter(&writer);
    if (!painter.isActive()) {
        qCritical() << "Failed to create PDF painter";
        return false;
    }
    
    QFont font = painter.font();
    font.setPointSize(10);
    painter.setFont(font);
    
    int y = 100;
    painter.drawText(100, y, "Аналитический отчет");
    y += 200;
    
    // Заголовки таблицы
    painter.drawText(100, y, "Смета");
    painter.drawText(1000, y, "Объект");
    painter.drawText(2000, y, "План труд.");
    painter.drawText(3000, y, "Факт труд.");
    painter.drawText(4000, y, "Откл. %");
    y += 150;
    
    // Данные
    for (const auto& row : data) {
        painter.drawText(100, y, row.estimateNumber);
        painter.drawText(1000, y, row.objectName);
        painter.drawText(2000, y, QString::number(row.plannedLabor, 'f', 2));
        painter.drawText(3000, y, QString::number(row.actualLabor, 'f', 2));
        painter.drawText(4000, y, QString::number(row.deviationPercent, 'f', 2));
        y += 150;
        
        if (y > 11000) {
            writer.newPage();
            y = 100;
        }
    }
    
    painter.end();
    return true;
}

bool AnalyticsService::exportToExcel(const QList<AnalyticsData>& data, const QString& filePath) {
    // Требуется библиотека QXlsx
    // Упрощенная реализация через CSV для совместимости
    return exportToCsv(filePath.replace(".xlsx", ".csv"), data);
}

bool AnalyticsService::exportToCsv(const QList<AnalyticsData>& data, const QString& filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qCritical() << "Failed to open file for writing:" << filePath;
        return false;
    }
    
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    
    // Заголовки
    out << "Смета;Объект;Плановые трудозатраты;Фактические трудозатраты;Отклонение %;";
    out << "Плановая стоимость;Фактическая стоимость;Отклонение по стоимости\n";
    
    // Данные
    for (const auto& row : data) {
        out << row.estimateNumber << ";";
        out << row.objectName << ";";
        out << QString::number(row.plannedLabor, 'f', 2) << ";";
        out << QString::number(row.actualLabor, 'f', 2) << ";";
        out << QString::number(row.deviationPercent, 'f', 2) << ";";
        out << QString::number(row.plannedCost, 'f', 2) << ";";
        out << QString::number(row.actualCost, 'f', 2) << ";";
        out << QString::number(row.costDeviation, 'f', 2) << "\n";
    }
    
    file.close();
    return true;
}
