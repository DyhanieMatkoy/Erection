#pragma once
#include "data/models/estimate.h"

class EstimateService {
public:
    Estimate* create();
    Estimate* load(int id);
    bool save(Estimate* estimate);
};
