#include "reference_picker_dialog.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QKeyEvent>
#include <QHeaderView>

ReferencePickerDialog::ReferencePickerDialog(const QString& tableName, const QString& displayColumn,
                                             QWidget* parent)
    : QDialog(parent), m_tableName(tableName), m_displayColumn(displayColumn) {
    setupUi();
    loadData();
}

void ReferencePickerDialog::setupUi() {
    setWindowTitle("Выбор из справочника");
    setModal(true);
    resize(600, 400);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    
    // Поиск
    QHBoxLayout* searchLayout = new QHBoxLayout();
    searchLayout->addWidget(new QLabel("Поиск:"));
    m_searchEdit = new QLineEdit();
    m_searchEdit->setPlaceholderText("Введите текст для поиска...");
    connect(m_searchEdit, &QLineEdit::textChanged, this, &ReferencePickerDialog::onSearchTextChanged);
    searchLayout->addWidget(m_searchEdit);
    mainLayout->addLayout(searchLayout);
    
    // Таблица
    m_tableView = new QTableView();
    m_tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_tableView->horizontalHeader()->setStretchLastSection(true);
    connect(m_tableView, &QTableView::doubleClicked, this, &ReferencePickerDialog::onTableDoubleClicked);
    mainLayout->addWidget(m_tableView);
    
    // Кнопки
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    m_selectButton = new QPushButton("Выбрать");
    m_selectButton->setDefault(true);
    connect(m_selectButton, &QPushButton::clicked, this, &ReferencePickerDialog::onSelectClicked);
    buttonLayout->addWidget(m_selectButton);
    
    m_cancelButton = new QPushButton("Отмена");
    connect(m_cancelButton, &QPushButton::clicked, this, &ReferencePickerDialog::onCancelClicked);
    buttonLayout->addWidget(m_cancelButton);
    mainLayout->addLayout(buttonLayout);
    
    m_searchEdit->setFocus();
}

void ReferencePickerDialog::loadData() {
    m_model = new QSqlTableModel(this, DatabaseManager::instance().database());
    m_model->setTable(m_tableName);
    m_model->setFilter("marked_for_deletion = 0");
    m_model->select();
    
    m_tableView->setModel(m_model);
    m_tableView->hideColumn(0); // Скрыть ID
    
    // Скрыть служебные колонки
    for (int i = 0; i < m_model->columnCount(); ++i) {
        QString colName = m_model->headerData(i, Qt::Horizontal).toString();
        if (colName == "marked_for_deletion" || colName == "user_id") {
            m_tableView->hideColumn(i);
        }
    }
}

void ReferencePickerDialog::onSearchTextChanged(const QString& text) {
    if (text.isEmpty()) {
        m_model->setFilter("marked_for_deletion = 0");
    } else {
        QString filter = QString("marked_for_deletion = 0 AND %1 LIKE '%%2%'")
                            .arg(m_displayColumn, text);
        m_model->setFilter(filter);
    }
    m_model->select();
}

void ReferencePickerDialog::onTableDoubleClicked(const QModelIndex& index) {
    if (!index.isValid()) return;
    
    int row = index.row();
    m_selectedId = m_model->data(m_model->index(row, 0)).toInt();
    
    // Найти колонку с displayColumn
    for (int col = 0; col < m_model->columnCount(); ++col) {
        if (m_model->headerData(col, Qt::Horizontal).toString() == m_displayColumn) {
            m_selectedValue = m_model->data(m_model->index(row, col)).toString();
            break;
        }
    }
    
    accept();
}

void ReferencePickerDialog::onSelectClicked() {
    QModelIndex index = m_tableView->currentIndex();
    if (index.isValid()) {
        onTableDoubleClicked(index);
    }
}

void ReferencePickerDialog::onCancelClicked() {
    reject();
}

void ReferencePickerDialog::keyPressEvent(QKeyEvent* event) {
    if (event->key() == Qt::Key_F4) {
        onSelectClicked();
    } else {
        QDialog::keyPressEvent(event);
    }
}
