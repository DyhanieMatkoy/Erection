#include "object_form.h"
#include "reference_picker_dialog.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QKeyEvent>
#include <QSqlQuery>
#include <QSqlError>

ObjectForm::ObjectForm(int id, QWidget* parent)
    : QWidget(parent), m_id(id) {
    setupUi();
    if (m_id > 0) {
        loadData();
    }
}

void ObjectForm::setupUi() {
    setWindowTitle(m_id > 0 ? "Редактирование объекта" : "Новый объект");
    setAttribute(Qt::WA_DeleteOnClose);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    
    // Форма
    QFormLayout* formLayout = new QFormLayout();
    
    m_nameEdit = new QLineEdit();
    connect(m_nameEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Наименование*:", m_nameEdit);
    
    // Владелец (FK Counterparty)
    QHBoxLayout* ownerLayout = new QHBoxLayout();
    m_ownerEdit = new QLineEdit();
    m_ownerEdit->setReadOnly(true);
    ownerLayout->addWidget(m_ownerEdit);
    
    m_ownerButton = new QPushButton("...");
    m_ownerButton->setMaximumWidth(30);
    connect(m_ownerButton, &QPushButton::clicked, this, &ObjectForm::onSelectOwner);
    ownerLayout->addWidget(m_ownerButton);
    
    formLayout->addRow("Владелец:", ownerLayout);
    
    m_addressEdit = new QLineEdit();
    connect(m_addressEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Адрес:", m_addressEdit);
    
    mainLayout->addLayout(formLayout);
    
    // Кнопки
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    
    m_saveButton = new QPushButton("Сохранить (Ctrl+S)");
    connect(m_saveButton, &QPushButton::clicked, this, &ObjectForm::onSave);
    buttonLayout->addWidget(m_saveButton);
    
    m_saveCloseButton = new QPushButton("Сохранить и закрыть (Ctrl+Shift+S)");
    connect(m_saveCloseButton, &QPushButton::clicked, this, &ObjectForm::onSaveAndClose);
    buttonLayout->addWidget(m_saveCloseButton);
    
    m_closeButton = new QPushButton("Закрыть (Esc)");
    connect(m_closeButton, &QPushButton::clicked, this, &ObjectForm::onClose);
    buttonLayout->addWidget(m_closeButton);
    
    mainLayout->addLayout(buttonLayout);
    
    m_nameEdit->setFocus();
}

void ObjectForm::loadData() {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT o.name, o.owner_id, c.name, o.address "
                  "FROM objects o "
                  "LEFT JOIN counterparties c ON o.owner_id = c.id "
                  "WHERE o.id = ?");
    query.addBindValue(m_id);
    
    if (query.exec() && query.next()) {
        m_nameEdit->setText(query.value(0).toString());
        m_ownerId = query.value(1).toInt();
        m_ownerEdit->setText(query.value(2).toString());
        m_addressEdit->setText(query.value(3).toString());
        m_isModified = false;
    }
}

bool ObjectForm::saveData() {
    if (m_nameEdit->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Наименование обязательно для заполнения");
        m_nameEdit->setFocus();
        return false;
    }
    
    QSqlQuery query(DatabaseManager::instance().database());
    
    if (m_id > 0) {
        query.prepare("UPDATE objects SET name = ?, owner_id = ?, address = ? WHERE id = ?");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_ownerId > 0 ? m_ownerId : QVariant());
        query.addBindValue(m_addressEdit->text());
        query.addBindValue(m_id);
    } else {
        query.prepare("INSERT INTO objects (name, owner_id, address) VALUES (?, ?, ?)");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_ownerId > 0 ? m_ownerId : QVariant());
        query.addBindValue(m_addressEdit->text());
    }
    
    if (query.exec()) {
        if (m_id <= 0) {
            m_id = query.lastInsertId().toInt();
        }
        m_isModified = false;
        setWindowTitle("Редактирование объекта");
        return true;
    } else {
        QMessageBox::critical(this, "Ошибка", "Не удалось сохранить: " + query.lastError().text());
        return false;
    }
}

void ObjectForm::onSelectOwner() {
    ReferencePickerDialog dialog("counterparties", "name", this);
    if (dialog.exec() == QDialog::Accepted) {
        m_ownerId = dialog.selectedId();
        m_ownerEdit->setText(dialog.selectedValue());
        m_isModified = true;
    }
}

void ObjectForm::onSave() {
    saveData();
}

void ObjectForm::onSaveAndClose() {
    if (saveData()) {
        close();
    }
}

void ObjectForm::onClose() {
    close();
}

void ObjectForm::closeEvent(QCloseEvent* event) {
    if (m_isModified) {
        QMessageBox::StandardButton reply = QMessageBox::question(
            this, "Несохраненные изменения",
            "Документ был изменен. Сохранить изменения?",
            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        
        if (reply == QMessageBox::Yes) {
            if (saveData()) {
                event->accept();
            } else {
                event->ignore();
            }
        } else if (reply == QMessageBox::No) {
            event->accept();
        } else {
            event->ignore();
        }
    } else {
        event->accept();
    }
}

void ObjectForm::keyPressEvent(QKeyEvent* event) {
    if (event->matches(QKeySequence::Save)) {
        onSave();
    } else if (event->key() == Qt::Key_S && 
               event->modifiers() == (Qt::ControlModifier | Qt::ShiftModifier)) {
        onSaveAndClose();
    } else if (event->key() == Qt::Key_Escape) {
        onClose();
    } else {
        QWidget::keyPressEvent(event);
    }
}
