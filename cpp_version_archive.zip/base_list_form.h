#pragma once
#include <QWidget>
#include <QTableView>
#include <QLineEdit>
#include <QToolBar>
#include <QSqlTableModel>

class BaseListForm : public QWidget {
    Q_OBJECT
    
public:
    explicit BaseListForm(QWidget* parent = nullptr);
    virtual ~BaseListForm() = default;
    
protected:
    virtual QString tableName() const = 0;
    virtual QString formTitle() const = 0;
    virtual void configureColumns() {}
    virtual QWidget* createEditForm(int id) = 0;
    
    void keyPressEvent(QKeyEvent* event) override;
    
private slots:
    void onCreateNew();
    void onOpen();
    void onDelete();
    void onSearch();
    void onCopy();
    void onSearchTextChanged(const QString& text);
    void onTableDoubleClicked(const QModelIndex& index);
    void onHeaderSectionResized(int logicalIndex, int oldSize, int newSize);
    
private:
    void setupUi();
    void loadData();
    void saveColumnSettings();
    void loadColumnSettings();
    
    QTableView* m_tableView;
    QLineEdit* m_searchEdit;
    QToolBar* m_toolBar;
    QSqlTableModel* m_model;
};
