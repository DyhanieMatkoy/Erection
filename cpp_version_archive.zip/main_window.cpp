#include "main_window.h"
#include <QMenuBar>
#include <QStatusBar>

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setupUi();
}

void MainWindow::setupUi() {
    setWindowTitle("Система управления рабочим временем");
    resize(1024, 768);
    
    auto fileMenu = menuBar()->addMenu("Файл");
    auto referencesMenu = menuBar()->addMenu("Справочники");
    auto documentsMenu = menuBar()->addMenu("Документы");
    auto reportsMenu = menuBar()->addMenu("Отчеты");
    
    statusBar()->showMessage("Готов");
}
