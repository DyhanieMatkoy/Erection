#pragma once
#include <QDialog>
#include <QLineEdit>
#include <QPushButton>

class LoginForm : public QDialog {
    Q_OBJECT
public:
    explicit LoginForm(QWidget* parent = nullptr);
    
private slots:
    void onLoginClicked();
    
private:
    void setupUi();
    QLineEdit* m_usernameEdit;
    QLineEdit* m_passwordEdit;
    QPushButton* m_loginButton;
};
