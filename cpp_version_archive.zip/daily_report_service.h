#pragma once
#include "data/models/daily_report.h"

class DailyReportService {
public:
    DailyReport* create(int estimateId);
    bool save(DailyReport* report);
};
