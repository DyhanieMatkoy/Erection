#pragma once
#include <QWidget>

class BaseDocumentForm : public QWidget {
    Q_OBJECT
public:
    explicit BaseDocumentForm(QWidget* parent = nullptr);
    
protected:
    void keyPressEvent(QKeyEvent* event) override;
    virtual void onSave();
    virtual void onSaveAndClose();
    virtual void onClose();
    virtual void onPrint();
    bool hasUnsavedChanges() const;
    
private:
    bool m_modified;
};
