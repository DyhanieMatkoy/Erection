#include "login_form.h"
#include "services/auth_service.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QLabel>
#include <QMessageBox>

LoginForm::LoginForm(QWidget* parent) : QDialog(parent) {
    setupUi();
}

void LoginForm::setupUi() {
    setWindowTitle("Вход в систему");
    setModal(true);
    
    auto layout = new QVBoxLayout(this);
    auto formLayout = new QFormLayout();
    
    m_usernameEdit = new QLineEdit(this);
    m_passwordEdit = new QLineEdit(this);
    m_passwordEdit->setEchoMode(QLineEdit::Password);
    
    formLayout->addRow("Логин:", m_usernameEdit);
    formLayout->addRow("Пароль:", m_passwordEdit);
    
    m_loginButton = new QPushButton("Войти", this);
    connect(m_loginButton, &QPushButton::clicked, this, &LoginForm::onLoginClicked);
    
    layout->addLayout(formLayout);
    layout->addWidget(m_loginButton);
}

void LoginForm::onLoginClicked() {
    QString username = m_usernameEdit->text();
    QString password = m_passwordEdit->text();
    
    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Заполните все поля");
        return;
    }
    
    auto user = AuthService::instance().login(username, password);
    if (user) {
        accept();
    } else {
        QMessageBox::warning(this, "Ошибка", "Неверный логин или пароль");
    }
}
