#include "database_manager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

DatabaseManager& DatabaseManager::instance() {
    static DatabaseManager instance;
    return instance;
}

bool DatabaseManager::initialize(const QString& dbPath) {
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(dbPath);
    
    if (!m_db.open()) {
        qCritical() << "Failed to open database:" << m_db.lastError().text();
        return false;
    }
    
    return createTables() && createIndices();
}

QSqlDatabase& DatabaseManager::database() {
    return m_db;
}

bool DatabaseManager::executeScript(const QString& script) {
    QSqlQuery query(m_db);
    return query.exec(script);
}

bool DatabaseManager::createTables() {
    QStringList tables = {
        // Users
        "CREATE TABLE IF NOT EXISTS users ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "username TEXT UNIQUE NOT NULL,"
        "password_hash TEXT NOT NULL,"
        "role TEXT NOT NULL,"
        "is_active INTEGER DEFAULT 1)",
        
        // Persons
        "CREATE TABLE IF NOT EXISTS persons ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "full_name TEXT NOT NULL,"
        "position TEXT,"
        "phone TEXT,"
        "user_id INTEGER REFERENCES users(id),"
        "marked_for_deletion INTEGER DEFAULT 0)",
        
        // Organizations
        "CREATE TABLE IF NOT EXISTS organizations ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "inn TEXT,"
        "default_responsible_id INTEGER REFERENCES persons(id),"
        "marked_for_deletion INTEGER DEFAULT 0)",
        
        // Counterparties
        "CREATE TABLE IF NOT EXISTS counterparties ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "inn TEXT,"
        "contact_person TEXT,"
        "phone TEXT,"
        "marked_for_deletion INTEGER DEFAULT 0)",
        
        // Objects
        "CREATE TABLE IF NOT EXISTS objects ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "owner_id INTEGER REFERENCES counterparties(id),"
        "address TEXT,"
        "marked_for_deletion INTEGER DEFAULT 0)",
        
        // Works
        "CREATE TABLE IF NOT EXISTS works ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "unit TEXT,"
        "price REAL,"
        "labor_rate REAL,"
        "marked_for_deletion INTEGER DEFAULT 0)",
        
        // Estimates
        "CREATE TABLE IF NOT EXISTS estimates ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "number TEXT NOT NULL,"
        "date DATE NOT NULL,"
        "customer_id INTEGER REFERENCES counterparties(id),"
        "object_id INTEGER REFERENCES objects(id),"
        "contractor_id INTEGER REFERENCES organizations(id),"
        "responsible_id INTEGER REFERENCES persons(id),"
        "total_sum REAL DEFAULT 0,"
        "total_labor REAL DEFAULT 0,"
        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
        "modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
        
        // Estimate Lines
        "CREATE TABLE IF NOT EXISTS estimate_lines ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "estimate_id INTEGER REFERENCES estimates(id) ON DELETE CASCADE,"
        "line_number INTEGER,"
        "work_id INTEGER REFERENCES works(id),"
        "quantity REAL,"
        "unit TEXT,"
        "price REAL,"
        "labor_rate REAL,"
        "sum REAL,"
        "planned_labor REAL)",
        
        // Daily Reports
        "CREATE TABLE IF NOT EXISTS daily_reports ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "date DATE NOT NULL,"
        "estimate_id INTEGER REFERENCES estimates(id),"
        "foreman_id INTEGER REFERENCES persons(id),"
        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
        "modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
        
        // Daily Report Lines
        "CREATE TABLE IF NOT EXISTS daily_report_lines ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "report_id INTEGER REFERENCES daily_reports(id) ON DELETE CASCADE,"
        "line_number INTEGER,"
        "work_id INTEGER REFERENCES works(id),"
        "planned_labor REAL,"
        "actual_labor REAL,"
        "deviation_percent REAL)",
        
        // Daily Report Executors
        "CREATE TABLE IF NOT EXISTS daily_report_executors ("
        "report_line_id INTEGER REFERENCES daily_report_lines(id) ON DELETE CASCADE,"
        "executor_id INTEGER REFERENCES persons(id),"
        "PRIMARY KEY (report_line_id, executor_id))",
        
        // User Settings
        "CREATE TABLE IF NOT EXISTS user_settings ("
        "user_id INTEGER REFERENCES users(id),"
        "form_name TEXT,"
        "setting_key TEXT,"
        "setting_value TEXT,"
        "PRIMARY KEY (user_id, form_name, setting_key))",
        
        // Constants
        "CREATE TABLE IF NOT EXISTS constants ("
        "key TEXT PRIMARY KEY,"
        "value TEXT)"
    };
    
    for (const QString& sql : tables) {
        if (!executeScript(sql)) {
            qCritical() << "Failed to create table:" << sql;
            return false;
        }
    }
    
    return true;
}

bool DatabaseManager::createIndices() {
    QStringList indices = {
        "CREATE INDEX IF NOT EXISTS idx_estimates_date ON estimates(date)",
        "CREATE INDEX IF NOT EXISTS idx_estimates_responsible ON estimates(responsible_id)",
        "CREATE INDEX IF NOT EXISTS idx_daily_reports_date ON daily_reports(date)",
        "CREATE INDEX IF NOT EXISTS idx_daily_reports_estimate ON daily_reports(estimate_id)"
    };
    
    for (const QString& sql : indices) {
        if (!executeScript(sql)) {
            qCritical() << "Failed to create index:" << sql;
            return false;
        }
    }
    
    return true;
}
