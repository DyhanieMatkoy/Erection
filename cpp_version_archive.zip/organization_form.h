#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>

class OrganizationForm : public QWidget {
    Q_OBJECT
    
public:
    explicit OrganizationForm(int id = -1, QWidget* parent = nullptr);
    
private slots:
    void onSave();
    void onSaveAndClose();
    void onClose();
    void onSelectDefaultResponsible();
    
private:
    void setupUi();
    void loadData();
    bool saveData();
    void closeEvent(QCloseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    
    int m_id;
    bool m_isModified = false;
    int m_defaultResponsibleId = -1;
    
    QLineEdit* m_nameEdit;
    QLineEdit* m_innEdit;
    QLineEdit* m_defaultResponsibleEdit;
    QPushButton* m_defaultResponsibleButton;
    QPushButton* m_saveButton;
    QPushButton* m_saveCloseButton;
    QPushButton* m_closeButton;
};
