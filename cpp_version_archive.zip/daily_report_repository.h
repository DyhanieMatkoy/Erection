#pragma once
#include "data/models/daily_report.h"

class DailyReportRepository {
public:
    DailyReport* findById(int id);
    bool save(DailyReport* report);
};
