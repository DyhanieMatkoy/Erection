#pragma once
#include "data/models/estimate.h"
#include <QList>

class EstimateRepository {
public:
    Estimate* findById(int id);
    bool save(Estimate* estimate);
    QList<Estimate*> findByResponsible(int personId);
    
private:
    void loadLines(Estimate* estimate);
    bool saveLines(Estimate* estimate);
};
