#pragma once
#include "document_view_model.h"
#include "data/models/estimate.h"

class EstimateViewModel : public DocumentViewModel {
    Q_OBJECT
public:
    explicit EstimateViewModel(QObject* parent = nullptr);
    
    void load(int id);
    bool save();
    void recalculate();
    
private:
    Estimate* m_estimate;
};
