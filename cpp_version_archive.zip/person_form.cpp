#include "person_form.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QKeyEvent>
#include <QSqlQuery>
#include <QSqlError>

PersonForm::PersonForm(int id, QWidget* parent)
    : QWidget(parent), m_id(id) {
    setupUi();
    if (m_id > 0) {
        loadData();
    }
}

void PersonForm::setupUi() {
    setWindowTitle(m_id > 0 ? "Редактирование физического лица" : "Новое физическое лицо");
    setAttribute(Qt::WA_DeleteOnClose);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    
    // Форма
    QFormLayout* formLayout = new QFormLayout();
    
    m_fullNameEdit = new QLineEdit();
    connect(m_fullNameEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("ФИО*:", m_fullNameEdit);
    
    m_positionEdit = new QLineEdit();
    connect(m_positionEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Должность:", m_positionEdit);
    
    m_phoneEdit = new QLineEdit();
    connect(m_phoneEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Телефон:", m_phoneEdit);
    
    mainLayout->addLayout(formLayout);
    
    // Кнопки
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    
    m_saveButton = new QPushButton("Сохранить (Ctrl+S)");
    connect(m_saveButton, &QPushButton::clicked, this, &PersonForm::onSave);
    buttonLayout->addWidget(m_saveButton);
    
    m_saveCloseButton = new QPushButton("Сохранить и закрыть (Ctrl+Shift+S)");
    connect(m_saveCloseButton, &QPushButton::clicked, this, &PersonForm::onSaveAndClose);
    buttonLayout->addWidget(m_saveCloseButton);
    
    m_closeButton = new QPushButton("Закрыть (Esc)");
    connect(m_closeButton, &QPushButton::clicked, this, &PersonForm::onClose);
    buttonLayout->addWidget(m_closeButton);
    
    mainLayout->addLayout(buttonLayout);
    
    m_fullNameEdit->setFocus();
}

void PersonForm::loadData() {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT full_name, position, phone FROM persons WHERE id = ?");
    query.addBindValue(m_id);
    
    if (query.exec() && query.next()) {
        m_fullNameEdit->setText(query.value(0).toString());
        m_positionEdit->setText(query.value(1).toString());
        m_phoneEdit->setText(query.value(2).toString());
        m_isModified = false;
    }
}

bool PersonForm::saveData() {
    if (m_fullNameEdit->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "ФИО обязательно для заполнения");
        m_fullNameEdit->setFocus();
        return false;
    }
    
    QSqlQuery query(DatabaseManager::instance().database());
    
    if (m_id > 0) {
        query.prepare("UPDATE persons SET full_name = ?, position = ?, phone = ? WHERE id = ?");
        query.addBindValue(m_fullNameEdit->text());
        query.addBindValue(m_positionEdit->text());
        query.addBindValue(m_phoneEdit->text());
        query.addBindValue(m_id);
    } else {
        query.prepare("INSERT INTO persons (full_name, position, phone) VALUES (?, ?, ?)");
        query.addBindValue(m_fullNameEdit->text());
        query.addBindValue(m_positionEdit->text());
        query.addBindValue(m_phoneEdit->text());
    }
    
    if (query.exec()) {
        if (m_id <= 0) {
            m_id = query.lastInsertId().toInt();
        }
        m_isModified = false;
        setWindowTitle("Редактирование физического лица");
        return true;
    } else {
        QMessageBox::critical(this, "Ошибка", "Не удалось сохранить: " + query.lastError().text());
        return false;
    }
}

void PersonForm::onSave() {
    saveData();
}

void PersonForm::onSaveAndClose() {
    if (saveData()) {
        close();
    }
}

void PersonForm::onClose() {
    close();
}

void PersonForm::closeEvent(QCloseEvent* event) {
    if (m_isModified) {
        QMessageBox::StandardButton reply = QMessageBox::question(
            this, "Несохраненные изменения",
            "Документ был изменен. Сохранить изменения?",
            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        
        if (reply == QMessageBox::Yes) {
            if (saveData()) {
                event->accept();
            } else {
                event->ignore();
            }
        } else if (reply == QMessageBox::No) {
            event->accept();
        } else {
            event->ignore();
        }
    } else {
        event->accept();
    }
}

void PersonForm::keyPressEvent(QKeyEvent* event) {
    if (event->matches(QKeySequence::Save)) {
        onSave();
    } else if (event->key() == Qt::Key_S && 
               event->modifiers() == (Qt::ControlModifier | Qt::ShiftModifier)) {
        onSaveAndClose();
    } else if (event->key() == Qt::Key_Escape) {
        onClose();
    } else {
        QWidget::keyPressEvent(event);
    }
}
