#pragma once
#include <QSqlDatabase>
#include <QString>

class DatabaseManager {
public:
    static DatabaseManager& instance();
    bool initialize(const QString& dbPath);
    QSqlDatabase& database();
    bool executeScript(const QString& script);
    
private:
    DatabaseManager() = default;
    ~DatabaseManager() = default;
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;
    
    QSqlDatabase m_db;
    bool createTables();
    bool createIndices();
};
