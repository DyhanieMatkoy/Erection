#pragma once
#include <QObject>

class ListViewModel : public QObject {
    Q_OBJECT
public:
    explicit ListViewModel(QObject* parent = nullptr);
};
