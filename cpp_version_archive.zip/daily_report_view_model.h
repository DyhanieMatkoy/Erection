#pragma once
#include "document_view_model.h"

class DailyReportViewModel : public DocumentViewModel {
    Q_OBJECT
public:
    explicit DailyReportViewModel(QObject* parent = nullptr);
};
