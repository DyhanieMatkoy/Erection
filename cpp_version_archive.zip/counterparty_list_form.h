#pragma once
#include "base_list_form.h"

class CounterpartyListForm : public BaseListForm {
    Q_OBJECT
    
public:
    explicit CounterpartyListForm(QWidget* parent = nullptr);
    
protected:
    QString tableName() const override { return "counterparties"; }
    QString formTitle() const override { return "Контрагенты"; }
    void configureColumns() override;
    QWidget* createEditForm(int id) override;
};
