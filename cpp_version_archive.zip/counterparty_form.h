#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>

class CounterpartyForm : public QWidget {
    Q_OBJECT
    
public:
    explicit CounterpartyForm(int id = -1, QWidget* parent = nullptr);
    
private slots:
    void onSave();
    void onSaveAndClose();
    void onClose();
    
private:
    void setupUi();
    void loadData();
    bool saveData();
    void closeEvent(QCloseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    
    int m_id;
    bool m_isModified = false;
    
    QLineEdit* m_nameEdit;
    QLineEdit* m_innEdit;
    QLineEdit* m_contactPersonEdit;
    QLineEdit* m_phoneEdit;
    QPushButton* m_saveButton;
    QPushButton* m_saveCloseButton;
    QPushButton* m_closeButton;
};
