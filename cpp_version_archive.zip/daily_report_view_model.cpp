#include "daily_report_view_model.h"

DailyReportViewModel::DailyReportViewModel(QObject* parent) : DocumentViewModel(parent) {
}
