#pragma once
#include <QObject>

class DocumentViewModel : public QObject {
    Q_OBJECT
public:
    explicit DocumentViewModel(QObject* parent = nullptr);
    
signals:
    void modified();
};
