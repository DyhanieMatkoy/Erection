#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>

class ObjectForm : public QWidget {
    Q_OBJECT
    
public:
    explicit ObjectForm(int id = -1, QWidget* parent = nullptr);
    
private slots:
    void onSave();
    void onSaveAndClose();
    void onClose();
    void onSelectOwner();
    
private:
    void setupUi();
    void loadData();
    bool saveData();
    void closeEvent(QCloseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    
    int m_id;
    bool m_isModified = false;
    int m_ownerId = -1;
    
    QLineEdit* m_nameEdit;
    QLineEdit* m_ownerEdit;
    QPushButton* m_ownerButton;
    QLineEdit* m_addressEdit;
    QPushButton* m_saveButton;
    QPushButton* m_saveCloseButton;
    QPushButton* m_closeButton;
};
