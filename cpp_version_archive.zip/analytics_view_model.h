#pragma once
#include <QObject>

class AnalyticsViewModel : public QObject {
    Q_OBJECT
public:
    explicit AnalyticsViewModel(QObject* parent = nullptr);
};
