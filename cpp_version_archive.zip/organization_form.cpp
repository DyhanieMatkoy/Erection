#include "organization_form.h"
#include "reference_picker_dialog.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCloseEvent>
#include <QKeyEvent>
#include <QSqlQuery>
#include <QSqlError>

OrganizationForm::OrganizationForm(int id, QWidget* parent)
    : QWidget(parent), m_id(id) {
    setupUi();
    if (m_id > 0) {
        loadData();
    }
}

void OrganizationForm::setupUi() {
    setWindowTitle(m_id > 0 ? "Редактирование организации" : "Новая организация");
    setAttribute(Qt::WA_DeleteOnClose);
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    
    // Форма
    QFormLayout* formLayout = new QFormLayout();
    
    m_nameEdit = new QLineEdit();
    connect(m_nameEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("Наименование*:", m_nameEdit);
    
    m_innEdit = new QLineEdit();
    connect(m_innEdit, &QLineEdit::textChanged, [this]() { m_isModified = true; });
    formLayout->addRow("ИНН:", m_innEdit);
    
    // Ответственный по умолчанию (FK Person)
    QHBoxLayout* responsibleLayout = new QHBoxLayout();
    m_defaultResponsibleEdit = new QLineEdit();
    m_defaultResponsibleEdit->setReadOnly(true);
    responsibleLayout->addWidget(m_defaultResponsibleEdit);
    
    m_defaultResponsibleButton = new QPushButton("...");
    m_defaultResponsibleButton->setMaximumWidth(30);
    connect(m_defaultResponsibleButton, &QPushButton::clicked, this, &OrganizationForm::onSelectDefaultResponsible);
    responsibleLayout->addWidget(m_defaultResponsibleButton);
    
    formLayout->addRow("Ответственный по умолчанию:", responsibleLayout);
    
    mainLayout->addLayout(formLayout);
    
    // Кнопки
    QHBoxLayout* buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    
    m_saveButton = new QPushButton("Сохранить (Ctrl+S)");
    connect(m_saveButton, &QPushButton::clicked, this, &OrganizationForm::onSave);
    buttonLayout->addWidget(m_saveButton);
    
    m_saveCloseButton = new QPushButton("Сохранить и закрыть (Ctrl+Shift+S)");
    connect(m_saveCloseButton, &QPushButton::clicked, this, &OrganizationForm::onSaveAndClose);
    buttonLayout->addWidget(m_saveCloseButton);
    
    m_closeButton = new QPushButton("Закрыть (Esc)");
    connect(m_closeButton, &QPushButton::clicked, this, &OrganizationForm::onClose);
    buttonLayout->addWidget(m_closeButton);
    
    mainLayout->addLayout(buttonLayout);
    
    m_nameEdit->setFocus();
}

void OrganizationForm::loadData() {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT o.name, o.inn, o.default_responsible_id, p.full_name "
                  "FROM organizations o "
                  "LEFT JOIN persons p ON o.default_responsible_id = p.id "
                  "WHERE o.id = ?");
    query.addBindValue(m_id);
    
    if (query.exec() && query.next()) {
        m_nameEdit->setText(query.value(0).toString());
        m_innEdit->setText(query.value(1).toString());
        m_defaultResponsibleId = query.value(2).toInt();
        m_defaultResponsibleEdit->setText(query.value(3).toString());
        m_isModified = false;
    }
}

bool OrganizationForm::saveData() {
    if (m_nameEdit->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Наименование обязательно для заполнения");
        m_nameEdit->setFocus();
        return false;
    }
    
    QSqlQuery query(DatabaseManager::instance().database());
    
    if (m_id > 0) {
        query.prepare("UPDATE organizations SET name = ?, inn = ?, default_responsible_id = ? WHERE id = ?");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_innEdit->text());
        query.addBindValue(m_defaultResponsibleId > 0 ? m_defaultResponsibleId : QVariant());
        query.addBindValue(m_id);
    } else {
        query.prepare("INSERT INTO organizations (name, inn, default_responsible_id) VALUES (?, ?, ?)");
        query.addBindValue(m_nameEdit->text());
        query.addBindValue(m_innEdit->text());
        query.addBindValue(m_defaultResponsibleId > 0 ? m_defaultResponsibleId : QVariant());
    }
    
    if (query.exec()) {
        if (m_id <= 0) {
            m_id = query.lastInsertId().toInt();
        }
        m_isModified = false;
        setWindowTitle("Редактирование организации");
        return true;
    } else {
        QMessageBox::critical(this, "Ошибка", "Не удалось сохранить: " + query.lastError().text());
        return false;
    }
}

void OrganizationForm::onSelectDefaultResponsible() {
    ReferencePickerDialog dialog("persons", "full_name", this);
    if (dialog.exec() == QDialog::Accepted) {
        m_defaultResponsibleId = dialog.selectedId();
        m_defaultResponsibleEdit->setText(dialog.selectedValue());
        m_isModified = true;
    }
}

void OrganizationForm::onSave() {
    saveData();
}

void OrganizationForm::onSaveAndClose() {
    if (saveData()) {
        close();
    }
}

void OrganizationForm::onClose() {
    close();
}

void OrganizationForm::closeEvent(QCloseEvent* event) {
    if (m_isModified) {
        QMessageBox::StandardButton reply = QMessageBox::question(
            this, "Несохраненные изменения",
            "Документ был изменен. Сохранить изменения?",
            QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        
        if (reply == QMessageBox::Yes) {
            if (saveData()) {
                event->accept();
            } else {
                event->ignore();
            }
        } else if (reply == QMessageBox::No) {
            event->accept();
        } else {
            event->ignore();
        }
    } else {
        event->accept();
    }
}

void OrganizationForm::keyPressEvent(QKeyEvent* event) {
    if (event->matches(QKeySequence::Save)) {
        onSave();
    } else if (event->key() == Qt::Key_S && 
               event->modifiers() == (Qt::ControlModifier | Qt::ShiftModifier)) {
        onSaveAndClose();
    } else if (event->key() == Qt::Key_Escape) {
        onClose();
    } else {
        QWidget::keyPressEvent(event);
    }
}
