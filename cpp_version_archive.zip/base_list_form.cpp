#include "base_list_form.h"
#include "../data/database_manager.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QAction>
#include <QKeyEvent>
#include <QMessageBox>
#include <QHeaderView>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

BaseListForm::BaseListForm(QWidget* parent) : QWidget(parent) {
    setupUi();
    loadData();
    loadColumnSettings();
}

void BaseListForm::setupUi() {
    setWindowTitle(formTitle());
    
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    
    // Панель инструментов
    m_toolBar = new QToolBar();
    
    QAction* createAction = m_toolBar->addAction("Создать (Insert/F9)");
    connect(createAction, &QAction::triggered, this, &BaseListForm::onCreateNew);
    
    QAction* openAction = m_toolBar->addAction("Открыть (Enter)");
    connect(openAction, &QAction::triggered, this, &BaseListForm::onOpen);
    
    QAction* deleteAction = m_toolBar->addAction("Удалить (Delete)");
    connect(deleteAction, &QAction::triggered, this, &BaseListForm::onDelete);
    
    m_toolBar->addSeparator();
    
    QAction* searchAction = m_toolBar->addAction("Поиск (Ctrl+F)");
    connect(searchAction, &QAction::triggered, this, &BaseListForm::onSearch);
    
    QAction* copyAction = m_toolBar->addAction("Копировать (Ctrl+D)");
    connect(copyAction, &QAction::triggered, this, &BaseListForm::onCopy);
    
    mainLayout->addWidget(m_toolBar);
    
    // Строка поиска
    QHBoxLayout* searchLayout = new QHBoxLayout();
    searchLayout->addWidget(new QLabel("Быстрый поиск:"));
    m_searchEdit = new QLineEdit();
    m_searchEdit->setPlaceholderText("Введите текст для фильтрации...");
    connect(m_searchEdit, &QLineEdit::textChanged, this, &BaseListForm::onSearchTextChanged);
    searchLayout->addWidget(m_searchEdit);
    mainLayout->addLayout(searchLayout);
    
    // Таблица
    m_tableView = new QTableView();
    m_tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_tableView->setSortingEnabled(true);
    m_tableView->horizontalHeader()->setStretchLastSection(true);
    connect(m_tableView, &QTableView::doubleClicked, this, &BaseListForm::onTableDoubleClicked);
    connect(m_tableView->horizontalHeader(), &QHeaderView::sectionResized,
            this, &BaseListForm::onHeaderSectionResized);
    mainLayout->addWidget(m_tableView);
}

void BaseListForm::loadData() {
    m_model = new QSqlTableModel(this, DatabaseManager::instance().database());
    m_model->setTable(tableName());
    m_model->setFilter("marked_for_deletion = 0");
    m_model->select();
    
    m_tableView->setModel(m_model);
    m_tableView->hideColumn(0); // Скрыть ID
    
    // Скрыть служебную колонку
    for (int i = 0; i < m_model->columnCount(); ++i) {
        QString colName = m_model->headerData(i, Qt::Horizontal).toString();
        if (colName == "marked_for_deletion") {
            m_tableView->hideColumn(i);
        }
    }
    
    configureColumns();
}

void BaseListForm::onCreateNew() {
    QWidget* form = createEditForm(-1);
    if (form) {
        form->show();
    }
}

void BaseListForm::onOpen() {
    QModelIndex index = m_tableView->currentIndex();
    if (!index.isValid()) return;
    
    int row = index.row();
    int id = m_model->data(m_model->index(row, 0)).toInt();
    
    QWidget* form = createEditForm(id);
    if (form) {
        form->show();
    }
}

void BaseListForm::onDelete() {
    QModelIndex index = m_tableView->currentIndex();
    if (!index.isValid()) return;
    
    int row = index.row();
    int id = m_model->data(m_model->index(row, 0)).toInt();
    
    // Проверка использования
    QSqlQuery query(DatabaseManager::instance().database());
    // Упрощенная проверка - можно расширить
    
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Подтверждение удаления",
        "Вы уверены, что хотите удалить выбранный элемент?",
        QMessageBox::Yes | QMessageBox::No);
    
    if (reply == QMessageBox::Yes) {
        query.prepare(QString("UPDATE %1 SET marked_for_deletion = 1 WHERE id = ?").arg(tableName()));
        query.addBindValue(id);
        
        if (query.exec()) {
            m_model->select();
        } else {
            QMessageBox::critical(this, "Ошибка", "Не удалось удалить элемент: " + query.lastError().text());
        }
    }
}

void BaseListForm::onSearch() {
    m_searchEdit->setFocus();
    m_searchEdit->selectAll();
}

void BaseListForm::onCopy() {
    QModelIndex index = m_tableView->currentIndex();
    if (!index.isValid()) return;
    
    // Копирование будет реализовано в конкретных формах
    QMessageBox::information(this, "Копирование", "Функция копирования будет реализована");
}

void BaseListForm::onSearchTextChanged(const QString& text) {
    if (text.isEmpty()) {
        m_model->setFilter("marked_for_deletion = 0");
    } else {
        // Поиск по всем текстовым колонкам
        QStringList conditions;
        for (int i = 1; i < m_model->columnCount(); ++i) {
            QString colName = m_model->headerData(i, Qt::Horizontal).toString();
            conditions << QString("%1 LIKE '%%2%'").arg(colName, text);
        }
        QString filter = QString("marked_for_deletion = 0 AND (%1)").arg(conditions.join(" OR "));
        m_model->setFilter(filter);
    }
    m_model->select();
}

void BaseListForm::onTableDoubleClicked(const QModelIndex& index) {
    if (index.isValid()) {
        onOpen();
    }
}

void BaseListForm::onHeaderSectionResized(int logicalIndex, int oldSize, int newSize) {
    saveColumnSettings();
}

void BaseListForm::saveColumnSettings() {
    // Сохранение настроек колонок в БД
    // Будет реализовано через SettingsService
}

void BaseListForm::loadColumnSettings() {
    // Загрузка настроек колонок из БД
    // Будет реализовано через SettingsService
}

void BaseListForm::keyPressEvent(QKeyEvent* event) {
    if (event->key() == Qt::Key_Insert || event->key() == Qt::Key_F9) {
        onCreateNew();
    } else if (event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter) {
        onOpen();
    } else if (event->key() == Qt::Key_Delete) {
        onDelete();
    } else if (event->matches(QKeySequence::Find)) {
        onSearch();
    } else if (event->key() == Qt::Key_D && event->modifiers() == Qt::ControlModifier) {
        onCopy();
    } else {
        QWidget::keyPressEvent(event);
    }
}
