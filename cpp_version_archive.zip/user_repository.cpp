#include "user_repository.h"
#include "data/database_manager.h"
#include <QSqlQuery>

User* UserRepository::findByUsername(const QString& username) {
    QSqlQuery query(DatabaseManager::instance().database());
    query.prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
    query.addBindValue(username);
    
    if (!query.exec() || !query.next()) {
        return nullptr;
    }
    
    auto user = new User();
    user->setId(query.value("id").toInt());
    user->setUsername(query.value("username").toString());
    user->setPasswordHash(query.value("password_hash").toString());
    user->setRole(query.value("role").toString());
    user->setIsActive(query.value("is_active").toBool());
    
    return user;
}
