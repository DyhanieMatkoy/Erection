#include "estimate_view_model.h"
#include "services/estimate_service.h"
#include "services/calculator_service.h"

EstimateViewModel::EstimateViewModel(QObject* parent) 
    : DocumentViewModel(parent), m_estimate(nullptr) {
}

void EstimateViewModel::load(int id) {
    EstimateService service;
    m_estimate = service.load(id);
}

bool EstimateViewModel::save() {
    if (!m_estimate) return false;
    
    EstimateService service;
    return service.save(m_estimate);
}

void EstimateViewModel::recalculate() {
    if (!m_estimate) return;
    
    double totalSum = 0.0;
    double totalLabor = 0.0;
    
    for (auto line : m_estimate->lines()) {
        line->setSum(CalculatorService::calculateSum(line->quantity(), line->price()));
        line->setPlannedLabor(CalculatorService::calculateLabor(line->quantity(), line->laborRate()));
        totalSum += line->sum();
        totalLabor += line->plannedLabor();
    }
    
    m_estimate->setTotalSum(totalSum);
    m_estimate->setTotalLabor(totalLabor);
    
    emit modified();
}
