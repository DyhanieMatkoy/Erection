#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QPushButton>

class WorkForm : public QWidget {
    Q_OBJECT
    
public:
    explicit WorkForm(int id = -1, QWidget* parent = nullptr);
    
private slots:
    void onSave();
    void onSaveAndClose();
    void onClose();
    
private:
    void setupUi();
    void loadData();
    bool saveData();
    void closeEvent(QCloseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    
    int m_id;
    bool m_isModified = false;
    
    QLineEdit* m_nameEdit;
    QLineEdit* m_unitEdit;
    QDoubleSpinBox* m_priceSpinBox;
    QDoubleSpinBox* m_laborRateSpinBox;
};
