#include "work_list_form.h"
#include "work_form.h"

WorkListForm::WorkListForm(QWidget* parent)
    : BaseListForm(parent) {
}

void WorkListForm::configureColumns() {
    // Настройка отображения колонок
}

QWidget* WorkListForm::createEditForm(int id) {
    return new WorkForm(id);
}
