#pragma once
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>

class PersonForm : public QWidget {
    Q_OBJECT
    
public:
    explicit PersonForm(int id = -1, QWidget* parent = nullptr);
    
private slots:
    void onSave();
    void onSaveAndClose();
    void onClose();
    
private:
    void setupUi();
    void loadData();
    bool saveData();
    void closeEvent(QCloseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    
    int m_id;
    bool m_isModified = false;
    
    QLineEdit* m_fullNameEdit;
    QLineEdit* m_positionEdit;
    QLineEdit* m_phoneEdit;
    QPushButton* m_saveButton;
    QPushButton* m_saveCloseButton;
    QPushButton* m_closeButton;
};
