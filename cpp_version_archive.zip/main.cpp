#include <QApplication>
#include "data/database_manager.h"
#include "views/login_form.h"
#include "views/main_window.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // Initialize database
    DatabaseManager::instance().initialize("construction.db");
    
    // Show login form
    LoginForm loginForm;
    if (loginForm.exec() == QDialog::Accepted) {
        MainWindow mainWindow;
        mainWindow.show();
        return app.exec();
    }
    
    return 0;
}
