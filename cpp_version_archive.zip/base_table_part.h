#pragma once
#include <QTableView>

class BaseTablePart : public QTableView {
    Q_OBJECT
public:
    explicit BaseTablePart(QWidget* parent = nullptr);
    
protected:
    void keyPressEvent(QKeyEvent* event) override;
    virtual void onInsertRow();
    virtual void onDeleteRow();
    virtual void onF4Pressed();
};
