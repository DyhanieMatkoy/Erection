#pragma once

class SettingsService {
public:
};
