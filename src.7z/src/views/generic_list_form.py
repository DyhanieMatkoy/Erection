from PyQt6.QtWidgets import QWidget, QVBoxLayout, QMessageBox, QHBoxLayout, QPushButton
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional, List, Dict, Any, Callable
from src.controllers.list_form_controller import ListFormController
from src.views.components.document_list_table import DocumentListTable
from src.views.components.filter_bar import FilterBar

class GenericListForm(QWidget):
    """
    Generic List Form implementation using Controller and Components.
    (Task 7 Integration)
    """
    
    # Signal when a document needs to be opened
    open_document_requested = pyqtSignal(int) # id (0 for new)
    
    def __init__(self, form_id: str, user_id: int, model_class: Any):
        super().__init__()
        self.controller = ListFormController(form_id, user_id, model_class)
        self.command_buttons = {}
        
        self.setup_ui()
        self.setup_callbacks()
        
        # Initialize
        self.controller.initialize()
        self.refresh_commands()
        # self.load_data() - moved to subclasses or explicit call, as columns might not be configured yet

    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Toolbar (Commands)
        self.toolbar_layout = QHBoxLayout()
        layout.addLayout(self.toolbar_layout)
        
        # Filter Bar
        self.filter_bar = FilterBar()
        self.filter_bar.search_changed.connect(self.on_search)
        self.filter_bar.filter_changed.connect(self.on_filter)
        layout.addWidget(self.filter_bar)
        
        # Table
        self.table = DocumentListTable()
        self.table.row_double_clicked.connect(self.on_row_double_click)
        self.table.selection_changed.connect(self.on_selection_change)
        self.table.sort_requested.connect(self.on_sort)
        self.table.column_resized.connect(self.on_column_resize)
        
        # Set style callback
        self.table.set_row_style_callback(self.get_row_style)
        
        layout.addWidget(self.table)
        self.setLayout(layout)

    def setup_callbacks(self):
        self.controller.set_callbacks(
            on_data_loaded=self.on_data_loaded,
            on_error=self.on_error
        )

    def configure_columns(self, columns: List[Dict]):
        """Configure columns from outside"""
        # Apply permission filtering
        filtered_columns = self.controller.filter_columns(columns)
        self.table.configure_columns(filtered_columns, self.controller.column_settings)
        
    def add_filter(self, key: str, label: str, options: list):
        """Add a filter to the bar"""
        self.filter_bar.add_filter(key, label, options)

    def refresh_commands(self):
        """Rebuild toolbar based on available commands"""
        # Clear existing
        while self.toolbar_layout.count():
            item = self.toolbar_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.command_buttons = {}
        
        # Get commands (pass current selection context)
        # Context usually includes selected items, but controller handles state
        # We might need to pass selection explicitly if controller doesn't track it fully sync?
        # Controller tracks selection in self.selection
        selection_context = {'selected_ids': list(self.controller.selection), 'selection_count': len(self.controller.selection)}
        commands = self.controller.get_available_commands(selection_context)
        
        for cmd in commands:
            label = cmd.get('label') or cmd.get('name') or cmd.get('id')
            btn = QPushButton(label)
            if cmd.get('icon'):
                # Set icon if available (skipped for now)
                pass
            
            # Enable/Disable based on command state
            btn.setEnabled(cmd.get('is_enabled', True))
            
            # Connect
            # We need to capture cmd_id
            cmd_id = cmd['id']
            btn.clicked.connect(lambda checked, cid=cmd_id: self.on_command(cid))
            
            self.toolbar_layout.addWidget(btn)
            self.command_buttons[cmd_id] = btn
            
        self.toolbar_layout.addStretch()

    def on_command(self, command_id: str):
        """Handle command execution"""
        if command_id == 'create':
            self.open_document_requested.emit(0)
        elif command_id == 'open':
            # Get selection
            sel = self.controller.get_selection()
            if len(sel) == 1:
                self.open_document_requested.emit(sel[0])
        elif command_id == 'refresh':
            self.load_data()
        else:
            # Delegate to subclass methods first (e.g. on_command_post)
            handler_name = f"on_command_{command_id}"
            if hasattr(self, handler_name):
                getattr(self, handler_name)()
                return

            # Delegate to controller/command manager
            try:
                # This assumes command manager executes logic. 
                # But command manager usually returns 'is_enabled'. 
                # Execution logic might be separate. 
                # Task 8 description said CommandManager handles logic.
                # Let's check CommandManager implementation.
                result = self.controller.execute_command(command_id)
                
                if result.get('success'):
                    if result.get('message'):
                        # Show status?
                        pass
                    if result.get('refresh_needed'):
                        self.load_data()
                else:
                    QMessageBox.warning(self, "Ошибка", result.get('error', "Unknown error"))
                    
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))

    def get_row_style(self, item: Any) -> Dict:
        """
        Determine row style based on item state.
        Default implementation handles common fields like is_posted, marked_for_deletion.
        """
        style = {}
        
        # Handle dict or object
        get_val = lambda k: item.get(k) if isinstance(item, dict) else getattr(item, k, None)
        
        if get_val('is_posted'):
            style['font_bold'] = True
            
        if get_val('marked_for_deletion'):
            style['foreground'] = "#A0A0A0" # Gray
            style['font_strike'] = True # Not implemented in table yet, but let's imagine
            
        return style

    def load_data(self):
        self.controller.load_data()

    def on_data_loaded(self, result: Dict):
        """Handle data loaded from controller"""
        items = result.get('items', [])
        self.table.set_data(items)
        # Update pagination controls (not implemented in UI yet)

    def on_error(self, message: str):
        QMessageBox.critical(self, "Ошибка", message)

    def on_search(self, text: str):
        # We assume controller has set_filter logic or we use specific search method
        # Controller has set_filter, but specific search might be separate or special filter key
        # Let's map search to a filter named 'search_text' or similar, 
        # or controller could have search method.
        # Controller has set_filter.
        # But wait, BaseListForm had explicit search param in load_data.
        # Controller implementation uses filters dict.
        # DataService uses filters dict.
        # Let's assume 'search' key is handled by DataService if needed, or we implement 'search' filter logic.
        # Actually DataService.get_documents takes filters.
        # We can pass 'search_text' filter?
        # Let's use 'search_text' as key.
        self.controller.set_filter('search_text', text)

    def on_filter(self, key: str, value: Any):
        self.controller.set_filter(key, value)

    def on_sort(self, column_id: str):
        self.controller.handle_sorting(column_id)

    def on_column_resize(self, column_id: str, width: int):
        self.controller.handle_column_resize(column_id, width)

    def on_row_double_click(self, item_id: int):
        # Open document
        pass

    def on_selection_change(self, selected_ids: List[int]):
        self.controller.update_selection(selected_ids)
        # Update command bar
        self.refresh_commands()

    def closeEvent(self, event):
        self.controller.close()
        super().closeEvent(event)
