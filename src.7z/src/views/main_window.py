"""Main window"""
from PyQt6.QtWidgets import (QMainWindow, QMenuBar, QStatusBar, QMdiArea, 
                              QDialog, QVBoxLayout, QLineEdit, QListWidget, 
                              QListWidgetItem, QLabel)
from PyQt6.QtGui import QAction, QKeySequence, QShortcut
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from collections import deque


class QuickNavigationDialog(QDialog):
    """Quick navigation dialog for fast access to forms"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.selected_action = None
        self.setup_ui()
        
        # Navigation items
        self.navigation_items = [
            ("Сметы", "open_estimates"),
            ("Ежедневные отчеты", "open_daily_reports"),
            ("Табели", "open_timesheets"),
            ("Контрагенты", "open_counterparties"),
            ("Объекты", "open_objects"),
            ("Организации", "open_organizations"),
            ("Физические лица", "open_persons"),
            
            ("Виды работ", "open_works"),
            ("Элементы затрат", "open_cost_items"),
            ("Материалы", "open_materials"),
            ("Выполнение работ", "open_work_execution_report"),
            ("Настройки синхронизации", "open_sync_settings"),
        ]
        
        self.populate_list()
    
    def setup_ui(self):
        """Setup UI"""
        self.setWindowTitle("Быстрая навигация")
        self.setModal(True)
        self.resize(400, 300)
        
        layout = QVBoxLayout()
        
        # Search field
        self.search_field = QLineEdit()
        self.search_field.setPlaceholderText("Введите название формы...")
        self.search_field.textChanged.connect(self.filter_list)
        layout.addWidget(self.search_field)
        
        # List widget
        self.list_widget = QListWidget()
        self.list_widget.itemDoubleClicked.connect(self.on_item_selected)
        layout.addWidget(self.list_widget)
        
        # Info label
        info_label = QLabel("Используйте стрелки для навигации, Enter для выбора")
        info_label.setStyleSheet("color: gray; font-size: 10px;")
        layout.addWidget(info_label)
        
        self.setLayout(layout)
        
        # Set focus to search field
        self.search_field.setFocus()
    
    def populate_list(self, filter_text=""):
        """Populate list with navigation items"""
        self.list_widget.clear()
        
        for name, action in self.navigation_items:
            if filter_text.lower() in name.lower():
                item = QListWidgetItem(name)
                item.setData(Qt.ItemDataRole.UserRole, action)
                self.list_widget.addItem(item)
        
        # Select first item
        if self.list_widget.count() > 0:
            self.list_widget.setCurrentRow(0)
    
    def filter_list(self, text):
        """Filter list based on search text"""
        self.populate_list(text)
    
    def on_item_selected(self, item):
        """Handle item selection"""
        self.selected_action = item.data(Qt.ItemDataRole.UserRole)
        self.accept()
    
    def keyPressEvent(self, event):
        """Handle key press events"""
        if event.key() == Qt.Key.Key_Return or event.key() == Qt.Key.Key_Enter:
            current_item = self.list_widget.currentItem()
            if current_item:
                self.on_item_selected(current_item)
        elif event.key() == Qt.Key.Key_Escape:
            self.reject()
        else:
            super().keyPressEvent(event)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        from ..services.auth_service import AuthService
        from ..services.sync_service import SyncService
        from ..data.database_manager import DatabaseManager
        
        self.auth_service = AuthService()
        
        # Initialize sync service with default parameters
        db_manager = DatabaseManager()
        self.sync_service = SyncService(
            db_manager=db_manager,
            server_url="http://localhost:8000",  # Default, can be changed in settings
            node_code="DESKTOP-CLIENT"  # Default, can be changed in settings
        )
        
        self.recent_forms = deque(maxlen=10)  # Track recently opened forms
        self.setup_ui()
        self.setup_shortcuts()
        self.setup_sync_status()
        
        # Show quick navigation on startup
        QTimer.singleShot(100, self.show_quick_navigation)
    
    def setup_ui(self):
        """Setup UI"""
        self.setWindowTitle("Система управления рабочим временем")
        self.resize(1024, 768)
        
        # Create MDI area for managing multiple windows
        self.mdi_area = QMdiArea()
        self.mdi_area.setViewMode(QMdiArea.ViewMode.TabbedView)  # Use tabbed view by default
        self.mdi_area.setTabsClosable(True)
        self.mdi_area.setTabsMovable(True)
        self.setCentralWidget(self.mdi_area)
        
        # Create menu bar
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("Файл")
        
        quick_nav_action = QAction("Быстрая навигация", self)
        quick_nav_action.setShortcut(QKeySequence("Ctrl+K"))
        quick_nav_action.triggered.connect(self.show_quick_navigation)
        file_menu.addAction(quick_nav_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Выход", self)
        exit_action.setShortcut(QKeySequence("Alt+F4"))
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # References menu
        references_menu = menubar.addMenu("Справочники")
        
        counterparties_action = QAction("Контрагенты", self)
        counterparties_action.triggered.connect(self.open_counterparties)
        counterparties_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(counterparties_action)
        self.counterparties_action = counterparties_action
        
        objects_action = QAction("Объекты", self)
        objects_action.triggered.connect(self.open_objects)
        objects_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(objects_action)
        self.objects_action = objects_action
        
        organizations_action = QAction("Организации", self)
        organizations_action.triggered.connect(self.open_organizations)
        organizations_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(organizations_action)
        self.organizations_action = organizations_action
        
        persons_action = QAction("Физические лица", self)
        persons_action.triggered.connect(self.open_persons)
        persons_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(persons_action)
        self.persons_action = persons_action
        
        # Nomenclature feature removed - see migration 20251208_140000_remove_nomenclatures_table.py
        # nomenclature_action = QAction("Номенклатура", self)
        # nomenclature_action.triggered.connect(self.open_nomenclature)
        # nomenclature_action.setEnabled(self.auth_service.can_manage_references())
        # references_menu.addAction(nomenclature_action)
        # self.nomenclature_action = nomenclature_action
        
        works_action = QAction("Виды работ", self)
        works_action.triggered.connect(self.open_works)
        works_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(works_action)
        self.works_action = works_action
        
        # Add separator
        references_menu.addSeparator()
        
        # Costs & Materials
        cost_items_action = QAction("Элементы затрат", self)
        cost_items_action.triggered.connect(self.open_cost_items)
        cost_items_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(cost_items_action)
        self.cost_items_action = cost_items_action
        
        materials_action = QAction("Материалы", self)
        materials_action.triggered.connect(self.open_materials)
        materials_action.setEnabled(self.auth_service.can_manage_references())
        references_menu.addAction(materials_action)
        self.materials_action = materials_action
        
        # Documents menu
        documents_menu = menubar.addMenu("Документы")
        
        estimates_action = QAction("Сметы", self)
        estimates_action.triggered.connect(self.open_estimates)
        documents_menu.addAction(estimates_action)
        
        daily_reports_action = QAction("Ежедневные отчеты", self)
        daily_reports_action.triggered.connect(self.open_daily_reports)
        documents_menu.addAction(daily_reports_action)
        
        timesheets_action = QAction("Табели", self)
        timesheets_action.setShortcut("Ctrl+Shift+T")
        timesheets_action.triggered.connect(self.open_timesheets)
        documents_menu.addAction(timesheets_action)
        
        # Reports menu
        reports_menu = menubar.addMenu("Отчеты")
        
        work_execution_action = QAction("Выполнение работ", self)
        work_execution_action.triggered.connect(self.open_work_execution_report)
        reports_menu.addAction(work_execution_action)
        
        # Window menu
        self.window_menu = menubar.addMenu("Окна")
        
        cascade_action = QAction("Каскадом", self)
        cascade_action.triggered.connect(self.cascade_windows)
        self.window_menu.addAction(cascade_action)
        
        tile_action = QAction("Мозаикой", self)
        tile_action.triggered.connect(self.tile_windows)
        self.window_menu.addAction(tile_action)
        
        self.window_menu.addSeparator()
        
        tabbed_view_action = QAction("Вкладки", self)
        tabbed_view_action.setCheckable(True)
        tabbed_view_action.setChecked(True)
        tabbed_view_action.triggered.connect(self.toggle_view_mode)
        self.window_menu.addAction(tabbed_view_action)
        self.tabbed_view_action = tabbed_view_action
        
        self.window_menu.addSeparator()
        
        close_active_action = QAction("Закрыть активное окно", self)
        close_active_action.setShortcut(QKeySequence("Ctrl+W"))
        close_active_action.triggered.connect(self.close_active_window)
        self.window_menu.addAction(close_active_action)
        
        close_all_action = QAction("Закрыть все окна", self)
        close_all_action.setShortcut(QKeySequence("Ctrl+Shift+W"))
        close_all_action.triggered.connect(self.close_all_windows)
        self.window_menu.addAction(close_all_action)
        
        self.window_menu.addSeparator()
        
        # Recent forms submenu
        self.recent_menu = self.window_menu.addMenu("Недавние")
        self.update_recent_menu()
        
        # Settings menu
        settings_menu = menubar.addMenu("Настройки")
        
        settings_action = QAction("Настройки программы", self)
        settings_action.triggered.connect(self.open_settings)
        settings_action.setEnabled(self.auth_service.can_manage_settings())
        settings_menu.addAction(settings_action)
        self.settings_action = settings_action
        
        sync_settings_action = QAction("Настройки синхронизации", self)
        sync_settings_action.triggered.connect(self.open_sync_settings)
        sync_settings_action.setEnabled(self.auth_service.can_manage_settings())
        settings_menu.addAction(sync_settings_action)
        self.sync_settings_action = sync_settings_action
        
        print_settings_action = QAction("Настройки печати", self)
        print_settings_action.triggered.connect(self.open_print_settings)
        settings_menu.addAction(print_settings_action)
        
        settings_menu.addSeparator()
        
        delete_marked_action = QAction("Удаление помеченных объектов", self)
        delete_marked_action.triggered.connect(self.open_delete_marked)
        delete_marked_action.setEnabled(self.auth_service.can_manage_references())
        settings_menu.addAction(delete_marked_action)
        self.delete_marked_action = delete_marked_action
        
        # Create status bar
        statusbar = self.statusBar()
        statusbar.showMessage("Готов")
        
        # Add sync status to status bar
        self.sync_status_label = QLabel("Синхронизация: Не настроена")
        self.sync_status_label.setStyleSheet("color: gray; margin-left: 10px;")
        statusbar.addPermanentWidget(self.sync_status_label)
    
    def setup_shortcuts(self):
        """Setup keyboard shortcuts"""
        # Quick navigation
        quick_nav_shortcut = QShortcut(QKeySequence("Ctrl+K"), self)
        quick_nav_shortcut.activated.connect(self.show_quick_navigation)
        
        # Window navigation
        next_window_shortcut = QShortcut(QKeySequence("Ctrl+Tab"), self)
        next_window_shortcut.activated.connect(self.next_window)
        
        prev_window_shortcut = QShortcut(QKeySequence("Ctrl+Shift+Tab"), self)
        prev_window_shortcut.activated.connect(self.previous_window)
        
        # Close window
        close_window_shortcut = QShortcut(QKeySequence("Ctrl+W"), self)
        close_window_shortcut.activated.connect(self.close_active_window)
    
    def show_quick_navigation(self):
        """Show quick navigation dialog"""
        dialog = QuickNavigationDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.selected_action:
            # Call the selected action
            if hasattr(self, dialog.selected_action):
                getattr(self, dialog.selected_action)()
    
    def add_to_recent(self, form_name, action_name):
        """Add form to recent list"""
        # Remove if already exists
        self.recent_forms = deque([item for item in self.recent_forms 
                                   if item[1] != action_name], maxlen=10)
        # Add to front
        self.recent_forms.appendleft((form_name, action_name))
        self.update_recent_menu()
    
    def update_recent_menu(self):
        """Update recent forms menu"""
        self.recent_menu.clear()
        
        if not self.recent_forms:
            no_recent_action = QAction("Нет недавних форм", self)
            no_recent_action.setEnabled(False)
            self.recent_menu.addAction(no_recent_action)
            return
        
        for form_name, action_name in self.recent_forms:
            action = QAction(form_name, self)
            action.triggered.connect(lambda checked, a=action_name: getattr(self, a)())
            self.recent_menu.addAction(action)
    
    def cascade_windows(self):
        """Arrange windows in cascade"""
        self.mdi_area.setViewMode(QMdiArea.ViewMode.SubWindowView)
        self.mdi_area.cascadeSubWindows()
        self.tabbed_view_action.setChecked(False)
    
    def tile_windows(self):
        """Arrange windows in tile"""
        self.mdi_area.setViewMode(QMdiArea.ViewMode.SubWindowView)
        self.mdi_area.tileSubWindows()
        self.tabbed_view_action.setChecked(False)
    
    def toggle_view_mode(self, checked):
        """Toggle between tabbed and subwindow view"""
        if checked:
            self.mdi_area.setViewMode(QMdiArea.ViewMode.TabbedView)
        else:
            self.mdi_area.setViewMode(QMdiArea.ViewMode.SubWindowView)
    
    def close_active_window(self):
        """Close active window"""
        active_window = self.mdi_area.activeSubWindow()
        if active_window:
            active_window.close()
    
    def close_all_windows(self):
        """Close all windows"""
        self.mdi_area.closeAllSubWindows()
    
    def next_window(self):
        """Activate next window"""
        self.mdi_area.activateNextSubWindow()
    
    def previous_window(self):
        """Activate previous window"""
        self.mdi_area.activatePreviousSubWindow()
    
    def open_estimates(self):
        """Open estimates list"""
        # Use new generic list form
        from .estimate_list_form_v2 import EstimateListFormV2 as EstimateListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), EstimateListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Сметы", "open_estimates")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = EstimateListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Сметы", "open_estimates")
    
    def open_daily_reports(self):
        """Open daily reports list"""
        from .daily_report_list_form_v2 import DailyReportListFormV2 as DailyReportListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), DailyReportListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Ежедневные отчеты", "open_daily_reports")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = DailyReportListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Ежедневные отчеты", "open_daily_reports")
    
    def open_timesheets(self):
        """Open timesheets list"""
        from .timesheet_list_form_v2 import TimesheetListFormV2 as TimesheetListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), TimesheetListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Табели", "open_timesheets")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = TimesheetListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Табели", "open_timesheets")
    
    def open_objects(self):
        """Open objects list"""
        from .object_list_form_v2 import ObjectListFormV2 as ObjectListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), ObjectListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Объекты", "open_objects")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = ObjectListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Объекты", "open_objects")
    
    def open_organizations(self):
        """Open organizations list"""
        from .organization_list_form_v2 import OrganizationListFormV2 as OrganizationListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), OrganizationListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Организации", "open_organizations")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = OrganizationListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Организации", "open_organizations")
    
    def open_persons(self):
        """Open persons list"""
        from .person_list_form import PersonListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), PersonListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Физические лица", "open_persons")
                return
        
        # Create new window
        form = PersonListForm()
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Физические лица", "open_persons")
    
    def open_works(self):
        """Open works list"""
        from .work_list_form_v2 import WorkListFormV2 as WorkListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), WorkListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Виды работ", "open_works")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = WorkListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Виды работ", "open_works")
    
    
    
    def open_counterparties(self):
        """Open counterparties list"""
        from .counterparty_list_form_v2 import CounterpartyListFormV2 as CounterpartyListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), CounterpartyListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Контрагенты", "open_counterparties")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = CounterpartyListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Контрагенты", "open_counterparties")
    
    def open_cost_items(self):
        """Open cost items list"""
        from .cost_item_list_form_v2 import CostItemListFormV2 as CostItemListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), CostItemListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Элементы затрат", "open_cost_items")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = CostItemListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Элементы затрат", "open_cost_items")
    
    def open_materials(self):
        """Open materials list"""
        from .material_list_form_v2 import MaterialListFormV2 as MaterialListForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), MaterialListForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Материалы", "open_materials")
                return
        
        # Create new window
        user_id = 1
        current_user = self.auth_service.current_user()
        if current_user:
            user_id = current_user.id
            
        form = MaterialListForm(user_id=user_id)
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Материалы", "open_materials")

    def open_work_execution_report(self):
        """Open work execution report"""
        from .work_execution_report_form import WorkExecutionReportForm
        
        # Check if already open
        for window in self.mdi_area.subWindowList():
            if isinstance(window.widget(), WorkExecutionReportForm):
                self.mdi_area.setActiveSubWindow(window)
                self.add_to_recent("Выполнение работ", "open_work_execution_report")
                return
        
        # Create new window
        form = WorkExecutionReportForm()
        sub_window = self.mdi_area.addSubWindow(form)
        sub_window.show()
        self.add_to_recent("Выполнение работ", "open_work_execution_report")
    
    def open_settings(self):
        """Open settings dialog"""
        from .settings_dialog import SettingsDialog
        dialog = SettingsDialog(self)
        dialog.exec()
    
    def open_print_settings(self):
        """Open print settings dialog"""
        from .print_settings_dialog import PrintSettingsDialog
        dialog = PrintSettingsDialog(self)
        dialog.exec()
    
    def open_delete_marked(self):
        """Open delete marked objects dialog"""
        from .delete_marked_dialog import DeleteMarkedDialog
        dialog = DeleteMarkedDialog(self)
        dialog.exec()
    
    def open_sync_settings(self):
        """Open synchronization settings dialog"""
        from .sync_settings_dialog import SyncSettingsDialog
        
        dialog = SyncSettingsDialog(self.sync_service, self)
        dialog.exec()
    
    def setup_sync_status(self):
        """Setup synchronization status monitoring"""
        # Connect to sync service signals
        self.sync_service.status_changed.connect(self.update_sync_status)
        
        # Update initial status
        self.update_sync_status()
    
    def update_sync_status(self):
        """Update sync status in status bar"""
        try:
            status = self.sync_service.get_sync_status()
            status_text = status.get('status', 'Unknown').title()
            
            if status.get('is_registered', False):
                if status_text == 'Online':
                    self.sync_status_label.setText("Синхронизация: Онлайн")
                    self.sync_status_label.setStyleSheet("color: green; margin-left: 10px;")
                elif status_text == 'Syncing':
                    self.sync_status_label.setText("Синхронизация: Выполняется")
                    self.sync_status_label.setStyleSheet("color: blue; margin-left: 10px;")
                else:
                    self.sync_status_label.setText("Синхронизация: Офлайн")
                    self.sync_status_label.setStyleSheet("color: orange; margin-left: 10px;")
            else:
                self.sync_status_label.setText("Синхронизация: Не настроена")
                self.sync_status_label.setStyleSheet("color: gray; margin-left: 10px;")
        except Exception as e:
            self.sync_status_label.setText("Синхронизация: Ошибка")
            self.sync_status_label.setStyleSheet("color: red; margin-left: 10px;")
