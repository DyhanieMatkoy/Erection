from PyQt6.QtWidgets import (QWidget, QHBoxLayout, QLabel, QLineEdit, 
                             QComboBox, QPushButton, QDateEdit)
from PyQt6.QtCore import pyqtSignal, Qt
from typing import Dict, Any

class FilterBar(QWidget):
    """
    Generic filter bar component (Task 7.5).
    Contains search box, date range, and custom filters.
    """
    
    filter_changed = pyqtSignal(str, object) # key, value
    search_changed = pyqtSignal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.filters = {} # active filters

    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Search
        layout.addWidget(QLabel("Поиск:"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Ctrl+F...")
        self.search_edit.textChanged.connect(self.on_search_text_changed)
        layout.addWidget(self.search_edit)
        
        # Container for dynamic filters
        self.dynamic_filters_layout = QHBoxLayout()
        layout.addLayout(self.dynamic_filters_layout)
        
        # Clear button
        self.clear_btn = QPushButton("Очистить")
        self.clear_btn.clicked.connect(self.clear_all)
        layout.addWidget(self.clear_btn)
        
        layout.addStretch()
        self.setLayout(layout)

    def add_filter(self, key: str, label: str, options: list):
        """
        Add a dropdown filter.
        options: list of (label, value) tuples
        """
        container = QWidget()
        l = QHBoxLayout()
        l.setContentsMargins(0, 0, 0, 0)
        l.addWidget(QLabel(f"{label}:"))
        
        combo = QComboBox()
        combo.addItem("Все", None)
        for opt_label, opt_value in options:
            combo.addItem(str(opt_label), opt_value)
            
        combo.currentIndexChanged.connect(lambda: self.on_combo_changed(key, combo))
        l.addWidget(combo)
        container.setLayout(l)
        
        self.dynamic_filters_layout.addWidget(container)
        self.filters[key] = combo

    def on_search_text_changed(self, text):
        self.search_changed.emit(text)

    def on_combo_changed(self, key, combo):
        value = combo.currentData()
        self.filter_changed.emit(key, value)

    def clear_all(self):
        self.search_edit.clear()
        for combo in self.filters.values():
            if isinstance(combo, QComboBox):
                combo.setCurrentIndex(0)
